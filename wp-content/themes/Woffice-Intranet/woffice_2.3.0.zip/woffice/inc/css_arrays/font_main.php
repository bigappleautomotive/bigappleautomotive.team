<?php
$font_main = array(
    '0' => 'body',
    '1' => 'p',
    '2' => '.main-menu li a.fa',
    '3' => 'h3.mv-addfile-title',
    '4' => '#content #eventon_form p label',
    '5' => '#content #eventon_form p #evoau_submit',
    '6' => '.mv-file-managing',
    '7' => 'table.mv-editfile th',
	'8' => '.widget_nav_menu li a.fa',
    '9' => '#dropdown-user-menu li a.fa',
);