<?php
$color_light3_color_important = array(
    0 => '#right-sidebar .widget .intern-padding ul li::before',
    1 => '#dashboard .widget .intern-padding ul li::before',
    2 => ' #content-container .masonry-layout .box ul li::before',
    3 => ' #content-container .learndash .notcompleted:after',
    4 => ' #content-container #learndash_profile .notcompleted:after',
    5 => ' #content-container .learndash .topic-notcompleted span:after',
    6 => ' .project-assigned-head i.fa',
);