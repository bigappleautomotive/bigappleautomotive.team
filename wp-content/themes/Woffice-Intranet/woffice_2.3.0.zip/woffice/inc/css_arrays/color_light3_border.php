<?php
$color_light3_border = array (
    0 => '#content-container .item-list-tabs ul li.last select',
    1 => ' .woocommerce #content-container div.product p.price del .amount:after',
    2 => ' input',
    3 => 'textarea',
	4 => 'select'
);