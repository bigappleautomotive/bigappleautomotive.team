<?php
$color_notifications_array_green = array (
    0 => '#buddypress div#message.updated',
    1 => ' #content-container div.wpcf7-mail-sent-ok',
    2 => ' #buddypress div#message.updated:hover',
    3 => ' #bp-avatar-feedback.updated.success',
);