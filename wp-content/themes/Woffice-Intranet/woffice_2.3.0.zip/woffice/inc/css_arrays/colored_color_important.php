<?php
$colored_color_important = array(
    0 => '#content-container .list-styled li:before',
    1 => ' #nav-cart-trigger.active',
    2 => '#main-content #buddypress div.activity-meta a.button:hover',
    3 => '#content-container .blog-next-page .navigation li.active a',
);