<?php
/**
 * This file contains all functions used by Woffice.
 * They're available in any PHP script loaded when the Woffice theme is enabled
 * All functions can be overwritten by a child theme
 * @author Alkaweb
 */

if(!function_exists('woffice_get_settings_option')) {
	/**
	 * Get the an option from theme settings
	 * 
	 * @param string $option
	 * @param string $default
	 *
	 * @return mixed|null|string
	 */
	function woffice_get_settings_option($option, $default = ''){
		return ( function_exists( 'fw_get_db_settings_option' ) ) ? fw_get_db_settings_option($option) : $default;	
	}
}

if(!function_exists('woffice_is_user_allowed')) {
    /**
     * Check whether a visitor is allowed or not for a certain post
     * @param null $post_id
     * @return bool|mixed|void
     */
    function woffice_is_user_allowed($post_id = null)
    {
        if(is_null($post_id))
            $post_id = get_the_ID();

        /* Fetch data from options both settings & post options */
        $exclude_members = (function_exists('fw_get_db_post_option')) ? fw_get_db_post_option($post_id, 'exclude_members') : '';
        $exclude_roles = (function_exists('fw_get_db_post_option')) ? fw_get_db_post_option($post_id, 'exclude_roles') : '';
        $logged_only = (function_exists('fw_get_db_post_option')) ? fw_get_db_post_option($post_id, 'logged_only') : '';
        if (empty($logged_only)) {
            $logged_only = false;
        }

        $user_ID = get_current_user_id();

        $is_allowed = true;

        /* We start by checking if the member is logged in and if the page allow you to view the content*/
        if ($logged_only == true && is_user_logged_in() == false || is_user_logged_in() && !current_user_can('woffice_read_wikies') && is_page_template('page-templates/wiki')) :
            $is_allowed = false;
        else :
            /* We check now if the user is excluded */
            $member_allowed = true;
            if (!empty($exclude_members)) :
                foreach ($exclude_members as $exclude_member) {
                    if ($exclude_member == $user_ID):
                        $member_allowed = false;
                    endif;
                }
            endif;
            /* We check now if the role is excluded */
            $role_allowed = true;
            if (!empty($exclude_roles)) :
                $user = wp_get_current_user();
                /* Thanks to Buddypress we only keep the main role */
                $the_user_role = (is_array($user->roles)) ? $user->roles[0] : $user->roles;

                /* We check if it's in the array, OR if it's the administrator  */
                if (in_array($the_user_role, $exclude_roles) && $the_user_role != "administrator") {
                    $role_allowed = false;
                }
            endif;
            /*We check the results*/
            if ($role_allowed == false || $member_allowed == false) {
                $is_allowed = false;
            }
        endif;

        //Allow to extend easily the function
        $is_allowed = apply_filters( 'woffice_is_user_allowed_return', $is_allowed );

        return $is_allowed;
    }
}



if(!function_exists('woffice_get_attachment_id_by_url')) {
    /**
     * Return Attachement's ID from its URL
     * @param $url
     * @return mixed
     */
    function woffice_get_attachment_id_by_url($url)
    {

        global $wpdb;
        $attachment = $wpdb->get_col("SELECT ID FROM $wpdb->posts WHERE guid LIKE '%".$url."';");


        if (isset($attachment[0]) && !empty($attachment[0])) {
            return $attachment[0];
        } else {
            return null;
        }

    }
}


if(!function_exists('woffice_title')) {
    /**
     * Display the HTML markup for the title bar in Woffice pages
     * It handles features images, BP titles, breadcrumbs, search bars, archives...
     * @param $title
     */
    function woffice_title($title)
    {
        echo '<!-- START FEATURED IMAGE AND TITLE -->';

        /*
         * WE SET THE CLASS
        */

        /*GET BUDDYPRESS AND CURENT POST INFO*/
        global $bp;
        global $post;
        /*THE MEMBERS & GROUP SLUG SET IN THE SETTINGS*/
        if (function_exists('bp_is_active')):
            $members_root = BP_MEMBERS_SLUG;
            //bp_is_members_directory
            if (bp_is_active('groups')) :
                $groups_root = BP_GROUPS_SLUG;
            else :
                $groups_root = "extensions-group-not-enabled";
            endif;
        endif;

        if(function_exists('is_bbpress') && is_bbpress()) {
            if(function_exists('bp_is_active') && bp_is_user()){
                $is_forum_page = false;
            } else {
                $is_forum_page = true;
            }
        } else {
            $is_forum_page = false;
        }

        /*THE CURRENT POST SLUG*/
        $post_name = (is_page()) ? get_post($post)->post_title : '';
        $current_slug = sanitize_title($post_name);

        if (is_search() || is_404() || is_page_template("page-templates/wiki.php") || is_page_template("page-templates/projects.php") || $is_forum_page):
            $title_class = "has-search is-404";
        elseif (is_page_template("page-templates/page-directory.php") || is_tax('directory-category')) :
            $title_class = "directory-header";
        else :
            $title_class = "";
        endif;
        if (function_exists('bp_is_active')):
            if (($groups_root == $current_slug) || (bp_is_members_directory())) :
                $title_class = "has-search search-buddypress";
            endif;
        endif;
        $post_top_featured = (function_exists('fw_get_db_post_option')) ? fw_get_db_post_option(get_the_ID(), 'post_top_featured') : '';
        $main_featured_image = woffice_get_settings_option('main_featured_image');

        /*
         * HTML
        */

        do_action('woffice_before_titlebox');

        echo '<header id="featuredbox" class="centered ' . esc_attr($title_class) . '">';

        /*We check for Revolution SLiders*/
        if (is_page() || (is_home() && get_option('page_for_posts'))) {
            $page_ID = (is_home() && get_option('page_for_posts')) ? get_option('page_for_posts') : get_the_ID();
            $slider_featured = (function_exists('fw_get_db_post_option')) ? fw_get_db_post_option($page_ID, 'revslider_featured') : '';
        } else {
            $slider_featured = "";
        }
        if (empty($slider_featured) || (!shortcode_exists('rev_slider') && !class_exists('FW_Extension_Slider'))) {

            echo '<div class="pagetitle animate-me fadeIn">';
            $hastitle = (function_exists('fw_get_db_post_option')) ? fw_get_db_post_option(get_the_ID(), 'hastitle') : '';
            if ($hastitle != true) :
                if (is_singular('post')) :
                    /*See: https://2f.ticksy.com/ticket/539682 */
                    if (function_exists('bp_is_active') && bp_is_user()) {
                        echo '<h1>';
                        if (defined('bp_displayed_user_mentionname')) {
                            bp_displayed_user_mentionname();
                        } else {
                            echo bp_get_displayed_user_fullname();
                        }
                        echo '</h1>';
                    } else {
                        $index_title = woffice_get_settings_option('index_title');
                        echo '<h1>' . $index_title . '</h1>';
                    }
                else:
                    echo '<h1>' . $title . '</h1>';
                endif;
                // CHECK FOR BREADCRUMB
                if (!is_front_page() && function_exists('fw_ext_breadcrumbs') && is_page() && !is_singular('wiki')) :
                    fw_ext_breadcrumbs();
                endif;
	            if(function_exists('fw_ext_breadcrumbs')
	               && ((function_exists('is_woocommerce') && is_woocommerce()) || (function_exists('is_product') && is_product())) ) {
		            woocommerce_breadcrumb(array(
                        'delimiter' => '',
                        'wrap_before' => '<div class="woobread breadcrumbs" itemprop="breadcrumb">',
                        'wrap_after' => '</div>',
                        'before' => '<span>',
                        'after' => '</span>',
                    ));
                }
                // SINGULAR WIKI PAGE -> WE DISPLAY PARENT LINK
                if (is_singular('wiki')):
                    echo empty($post->post_parent) ? '' : get_the_title($post->post_parent);
                endif;
            endif;
            if (is_search() || is_404() || is_page_template("page-templates/wiki.php") || is_page_template("page-templates/projects.php") || $is_forum_page):
                if($is_forum_page){
                    echo do_shortcode('[bbp-search]');
                } else {
                    get_search_form();
                }
            endif;
            // BUDDYPRESS SEARHFORMS
            if (function_exists('bp_is_active')):
                /*THEN WE CHECK*/
                if ($groups_root == $current_slug) :
                    bp_woffice_directory_groups_search_form();
                endif;
                if (bp_is_members_directory()) :
                    bp_woffice_directory_members_search_form();
                endif;
            endif;
            //DIRECTORY STUFF
            if (is_page_template("page-templates/page-directory.php") || is_tax('directory-category')) {
                echo '<div class="title-box-buttons">';
                echo '<div id="directory-search">';
                get_search_form();
                echo '</div>';
                echo '<a href="javascript:void(0)" class="btn btn-default" id="directory-show-search"><i class="fa fa-search"></i> ' . __('Search', 'woffice') . '</a>';
                $directory_create = woffice_get_settings_option('directory_create');
                /*if (woffice_role_allowed($directory_create)):
                    echo '<a href="javascript:void(0)" class="btn btn-default" id="directory-add-item"><i class="fa fa-plus-square"></i> '. __('Create a new item','woffice') .'</a>';
                endif;*/
                echo '</div>';
            }
            echo '</div>';
            if ((has_post_thumbnail() && is_page()) || (is_singular('directory') && has_post_thumbnail())) :
                $image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full');
                $final_image = $image[0];
                echo '<div class="featured-background" style="background-image:url(' . esc_url($final_image) . ');">';
            elseif (is_single() && !empty($post_top_featured)) :
                $final_image = $post_top_featured["url"];
                echo '<div class="featured-background" style="background-image:url(' . esc_url($final_image) . ');">';
            elseif (is_page_template("page-templates/page-directory.php") || is_tax('directory-category')):
                if (!has_post_thumbnail()) {
                    echo '<div id="map-directory"></div>';
                } else {
                    $image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full');
                    $final_image = $image[0];
                    echo '<div class="featured-background" style="background-image:url(' . esc_url($final_image) . ');">';
                }
            elseif (!empty($main_featured_image)):
                echo '<div class="featured-background" style="background-image: url(' . esc_url($main_featured_image['url']) . ');">';
	            $final_image = $main_featured_image['url'];
            else :
                if (is_home() && get_option('page_for_posts')) {
                    $image = wp_get_attachment_image_src(get_post_thumbnail_id(get_option('page_for_posts')), 'full');
                    $final_image = $image[0];
                    echo '<div class="featured-background" style="background-image:url(' . esc_url($final_image) . ');">';
                } else {
                    echo '<div class="featured-background" style="background-image: url(' . get_template_directory_uri() . '/images/1.jpg);">';
                }
            endif;

	        //Get the id of the attachment by the attachment url

	        if(!empty($final_image)) {
		        $attachment = woffice_get_attachment_id_by_url($final_image );

		        woffice_print_css_breakpoints_for_image_loading($attachment);

	        }

            echo '<div class="featured-background">
				<div class="featured-layer"></div>
			</div>';
        } else {
            /*We look for an Unyson slider first (an numerical post id and not a revolution slider slug */
            if (is_numeric($slider_featured)){
	            $revolution_slider_shortcode = apply_filters('woffice_revolution_slider_shortcode', '[slider slider_id="'.$slider_featured.'" width="1200" height="auto" /]', $slider_featured);
                echo do_shortcode($revolution_slider_shortcode);
            } else{
                // LAST CHECK
                if (shortcode_exists('rev_slider')) {
                    putRevSlider($slider_featured);
                }
            }
        }
        echo '</header>';

        do_action('woffice_after_titlebox');

    }
}
if(!function_exists('woffice_print_css_breakpoints_for_image_loading')) {
	function woffice_print_css_breakpoints_for_image_loading($attachment_id){
		if(is_null($attachment_id))
			return;

		// Full
		$image_full_url = wp_get_attachment_url(  $attachment_id ) ;
		// 800x600?
		$image_large_url = wp_get_attachment_image_src( $attachment_id, array(800,600) );

		//Set breakpoints to see a different image depending on window size and retina display
		echo '<style>
	        @media screen and (max-width: 800px) {
		        .featured-background {
			        background-image: url("'.$image_large_url[0].'") !important;
				  background-image: 
				    -webkit-image-set(
					    "'.$image_large_url[0].'" 1x,
				      "'.$image_full_url.'" 2x,
				    ) !important;
				  background-image: 
				    image-set(
					    "'.$image_large_url[0].'" 1x,
				      "'.$image_full_url.'" 2x,
				    ) !important;
				}
	        }
			</style>';

	}
}

if(!function_exists('woffice_sort_objects_by_name')) {
    /**
     * Binary safe string comparison
     * @link http://php.net/manual/en/function.strcmp.php
     * @param $a
     * @param $b
     * @return int
     */
    function woffice_sort_objects_by_name($a, $b)
    {
        return strcmp($a->name, $b->name);
    }
}

if(!function_exists('woffice_sort_objects_by_post_title')) {
    /**
     * Binary safe string comparison between posts
     * @link http://php.net/manual/en/function.strcmp.php
     * @param $a
     * @param $b
     * @return int
     */
    function woffice_sort_objects_by_post_title($a, $b)
    {
        return strcmp($a->post_title, $b->post_title);
    }
}

if(!function_exists('woffice_paging_nav')) {
    /**
     * Creating custom pagination for Woffice
     * @param null $custom_query
     */
    function woffice_paging_nav($custom_query = null)
    {
        if(is_singular() && is_null($custom_query))
            return;

        if(is_null($custom_query)) {
            global $wp_query;
            $custom_query = $wp_query;
        }

        $total_pages = $custom_query->max_num_pages;

        /** Stop execution if there's only 1 page */
        if ($total_pages <= 1)
            return;

        $max = intval($total_pages);
        global $paged;
        $paged = (empty($paged)) ? 1 : $paged;


        /**    Add current page to the array */
        if ($paged >= 1)
            $links[] = $paged;

        /**    Add the pages around the current page to the array */
        if ($paged >= 3) {
            $links[] = $paged - 1;
            $links[] = $paged - 2;
        }

        if (($paged + 2) <= $max) {
            $links[] = $paged + 2;
            $links[] = $paged + 1;
        }

        echo '<div class="blog-next-page center">' . "\n";

        echo '<ul class="navigation clearfix">' . "\n";

        /**    Previous Post Link */
        if ($paged > 1) {
            $previous_posts_link = explode('"', get_previous_posts_link());
            $npl_url = $previous_posts_link[1];
            echo '<li><a href="' . esc_url($previous_posts_link[1]) . '" class="btn btn-default"><i class="fa fa-hand-o-left"></i> ' . __('Previous Posts', 'woffice') . '</a></li>';
        }

        /**    Link to first page, plus ellipses if necessary */
        if (!in_array(1, $links)) {
            $class = (1 == $paged) ? ' class="active"' : '';

            printf('<li%s><a class="btn btn-default" href="%s">%s</a></li>' . "\n", $class, esc_url(get_pagenum_link(1)), '1');

            if (!in_array(2, $links))
                echo '<li><span class="btn btn-default disabled">...</span></li>';
        }

        /**    Link to current page, plus 2 pages in either direction if necessary */
        sort($links);
        foreach ((array)$links as $link) {
            $class = $paged == $link ? ' class="active"' : '';
            printf('<li%s><a class="btn btn-default" href="%s">%s</a></li>' . "\n", $class, esc_url(get_pagenum_link($link)), $link);
        }

        /**    Link to last page, plus ellipses if necessary */
        if (!in_array($max, $links)) {
            if (!in_array($max - 1, $links))
                echo '<li><span class="btn btn-default disabled">...</span></li>' . "\n";

            $class = $paged == $max ? ' class="active"' : '';
            printf('<li%s><a class="btn btn-default" href="%s">%s</a></li>' . "\n", $class, esc_url(get_pagenum_link($max)), $max);
        }

        /**    Next Post Link */
        if ($paged < $max) {
            $next_posts_link = explode('"', get_next_posts_link('', $max));
            echo '<li><a href="' . esc_url($next_posts_link[1]) . '" class="btn btn-default">' . __('Next Posts', 'woffice') . ' <i class="fa fa-hand-o-right"></i></a></li>';
        }

        echo '</ul>' . "\n";

        echo '</div>' . "\n";
    }
}

if(!function_exists('woffice_post_nav')) {
    /**
     * Custom post navigation for Woffice
     */
    function woffice_post_nav()
    {
        // Don't print empty markup if there's nowhere to navigate.
        $previous = (is_attachment()) ? get_post(get_post()->post_parent) : get_adjacent_post(false, '',
            true);
        $next = get_adjacent_post(false, '', false);
        if (!$next && !$previous) {
            return;
        }
        echo '
		<hr><div class="blog-next-page center animate-me fadeInUp" role="navigation">' . "\n";
        ob_start();
        previous_post_link('%link',
            __('<i class="fa fa-hand-o-left"></i> %title', 'woffice'));
        next_post_link('%link',
            __('%title <i class="fa fa-hand-o-right"></i>', 'woffice'));
        $link = ob_get_clean();
        echo str_replace('<a ', '<a class="btn btn-default" ', $link);


        echo '</div>' . "\n";
    }
}

if(!function_exists('woffice_postmetas')) {
    /**
     * Handling Woffice post metadatas
     * That's the information that goes with any WP post by default
     */
    function woffice_postmetas()
    {
        echo '<ul class="post-metadatas list-inline">';
        echo '<li><i class="fa fa-clock-o"></i> ' . get_the_date() . '</li>';
        echo '<li><span class="author vcard"><i class="fa fa-user" aria-hidden="true"></i><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span></li>';
        if (get_comment_count(get_the_ID()) > 0 && comments_open()) {
            echo '<li><i class="fa fa-comments-o"></i> <a href="' . get_the_permalink() . '#respond">' . get_comments_number('0', '1', '%') . '</a></li>';
        }
        if (get_the_category_list() != "") {
            echo '<li><i class="fa fa-thumb-tack"></i> ' . get_the_category_list(__(', ', 'woffice')) . '</li>';
        }
        if (get_the_tag_list() != "") {
            echo '<li class="meta-tags"><i class="fa fa-tags"></i> ' . get_the_tag_list('', __(', ', 'woffice')) . '</li>';
        }
        echo '</ul>';
    }
}

if(!function_exists('woffice_favicons')) {
    /**
     * Displaying favicons HTML markup
     */
    function woffice_favicons()
    {
        $favicon = woffice_get_settings_option('favicon');
        echo (!empty($favicon)) ? '<link rel="shortcut icon" type="image/png" href="' . esc_url($favicon['url']) . '">' : '';

        $favicon_android_1 = woffice_get_settings_option('favicon_android_1');
        $favicon_android_2 = woffice_get_settings_option('favicon_android_2');
        if (!empty($favicon_android_1) || !empty($favicon_android_2)):
            echo '<link rel="manifest" href="' . get_template_directory_uri() . '/js/manifest.json">';
        endif;

        $favicon_iphone = woffice_get_settings_option('favicon_iphone');
        echo (!empty($favicon_iphone)) ? '<link rel="apple-touch-icon" sizes="114x114" href="' . esc_url($favicon_iphone['url']) . '">' : '';

        $favicon_ipad = woffice_get_settings_option('favicon_ipad');
        echo (!empty($favicon_ipad)) ? '<link rel="apple-touch-icon" sizes="144x144" href="' . esc_url($favicon_ipad['url']) . '">' : '';
    }
}

if(!function_exists('woffice_scroll_top')) {
    /**
     * Display HTML markup for the scroll to the top button
     */
    function woffice_scroll_top()
    {
        $sidebar_scroll = woffice_get_settings_option('sidebar_scroll');
        $is_blank_template = woffice_is_current_page_using_blank_template();

        if ($sidebar_scroll == "yep" && !$is_blank_template) : ?>
            <!--SCROLL TOP-->
            <div id="scroll-top-container">
                <a href="#main-header" id="scroll-top">
                    <i class="fa fa-arrow-circle-o-up"></i>
                </a>
            </div>
        <?php endif;
    }
}

if(!function_exists('woffice_language_switcher')) {
    /**
     * Language switcher HTML markup
     */
    function woffice_language_switcher()
    {

        // IF IS WPML ENABLE
        if (class_exists('SitePress')) {
            function getActiveLanguage()
            {
                // fetches the list of languages
                $languages = icl_get_languages('skip_missing=N&orderby=KEY&order=DIR');
                $activeLanguage = 'Englsih';
                // runs through the languages of the system, finding the active language
                foreach ($languages as $language) {
                    // tests if the language is the active one
                    if ($language['active'] == 1) {
                        $activeLanguage = $language['native_name'];
                    }
                }
                return $activeLanguage;
            }

            $languages = icl_get_languages('skip_missing=0&orderby=code');
            if (!empty($languages)) {
                echo '<div id="nav-languages">';
                echo '<a href="javascript:void(0)">
	    		<i class="fa fa-flag"></i><em>' . getActiveLanguage() . '</em> <i class="fa fa-angle-down"></i>
	    	</a>';
                echo '<ul>';
                foreach ($languages as $l) {
                    if (!$l['active'] == 1) {
                        echo '<li class="menu-item"><a href="' . esc_url($l['url']) . '">' . esc_html($l['translated_name']) . '</a></li>';
                    }
                }
                echo '</ul></div>';
            }
        } // ELSE IF TRANSLATE UNYSON EXTENSION IS HERE
        elseif (function_exists('fw_ext_translation_get_frontend_active_language')) {
            echo '<div id="nav-languages">
		<a href="javascript:void(0)">
			<i class="fa fa-flag"></i>' . esc_html(fw_ext('translation')->get_frontend_active_language()) . ' <i class="fa fa-angle-down"></i>
		</a>';
            fw_ext('translation')->frontend_language_switcher();
            echo '</div>';
        } // ELSE RETURN NOTHING
        else {
            return;
        }
    }
}

if (!function_exists('woffice_get_sidebar_state')) {
    /**
     * Get Woffice Right Sidebar state
     * @return string : hide | show | nope
     */
    function woffice_get_sidebar_state()
    {

        /* Data from the database */
        $sidebar_show = woffice_get_settings_option('sidebar_show');
        $sidebar_state = woffice_get_settings_option('sidebar_state');
        $sidebar_only_logged = woffice_get_settings_option('sidebar_only_logged');
        $sidebar_blog = woffice_get_settings_option('sidebar_blog');
        $sidebar_buddypress = woffice_get_settings_option('sidebar_buddypress');

        /* Checks and returns : none|hide|show */

        /* We first check it it's for every one AND   */
        if ($sidebar_only_logged == "yep" && !is_user_logged_in()) {
            return "none";
        } else {
            /* We check for the page and if it's hidden */
            $page_url = $_SERVER['REQUEST_URI'];
            if (function_exists('bp_is_active')) {
                global $bp;
                $members_root = (bp_is_active('members')) ? BP_MEMBERS_SLUG : 'not-in-the-url';
                $groups_root = (bp_is_active('groups')) ? BP_GROUPS_SLUG : 'not-in-the-url';
                // We check if the root is in the url
                $slug_position_members = stripos($page_url, $members_root);
                $slug_position_groups = stripos($page_url, $groups_root);
                // We are in a member page or Group page ?
                $is_members_page = ($slug_position_members !== false) ? true : false;
                $is_groups_page = ($slug_position_groups !== false) ? true : false;
            } else {
                $is_members_page = false;
                $is_groups_page = false;
            }

            if ($sidebar_buddypress == "nope" && ($is_members_page == true || $is_groups_page == true)) {
                return "none";
            } elseif ($sidebar_blog == "nope" && (is_singular('post') || is_home() || is_page_template("page-templates/blog.php"))) {
                return "none";
            } else {
                /* We check then if it's hidden, not active or not the full width template */
                if ($sidebar_show == "hide" || !is_active_sidebar('content') || is_page_template("page-templates/full-width.php")) {
                    return "none";
                } else {
                    if ($sidebar_state == "nope") {
                        return "hide";
                    } else {
                        return "show";

                    }
                }
            }
        }

    }
}

if(!function_exists('validate_gravatar')) {
    /**
     * Check wheter there is a gravatar image to find or note
     * @note if you've many users this function will slow your server down
     * @param $id_of_user
     * @return bool
     */
    function validate_gravatar($id_of_user)
    {
        //id or email code borrowed from wp-includes/pluggable.php

        $id = (int)$id_of_user;
        $user = get_userdata($id);
        $email = ($user) ? $user->user_email : '';

        $hashkey = md5(strtolower(trim($email)));
        $uri = 'http://www.gravatar.com/avatar/' . $hashkey . '?d=404';

        $data = wp_cache_get($hashkey);
        if (false === $data) {
            $response = wp_remote_head($uri);
            if (is_wp_error($response)) {
                $data = 'not200';
            } else {
                $data = $response['response']['code'];
            }
            wp_cache_set($hashkey, $data, $group = '', $expire = 60 * 5);

        }
        if ($data == '200') {
            return true;
        } else {
            //Check if link is not a gravat link, so it mean that is an avatar uploaded on site, in this case return true
            $avatar_url = get_avatar($id, 80);
            return (strpos($avatar_url, 'gravatar') === FALSE);

        }
    }
}

if(!function_exists('woffice_extrafooter')) {
    /**
     * Display the extrafooter markup in the footer
     */
    function woffice_extrafooter()
    {
        // GET THE OPTIONS
        $extrafooter_content = woffice_get_settings_option('extrafooter_content');
        $extrafooter_link = woffice_get_settings_option('extrafooter_link');


        // FRONTEND DISPLAY
        echo '<!-- START EXTRAFOOTER -->';
        echo '<section id="extrafooter">';
        echo '<div id="extrafooter-layer" class="animate-me fadeIn">';
        echo '<a href="' . esc_url($extrafooter_link) . '"><h1>' . $extrafooter_content . '</h1></a>';
        echo '</div>';
        echo '<div id="familiers">';

	    $member_ids = get_transient( 'woffice_extrafooter_member_ids' );
	    woffice_extrafooter_print_avatars($member_ids);

        echo '</div>';
        echo '</section>';
    }
}

if(!function_exists('woffice_extrafooter_print_avatars')) {
	function woffice_extrafooter_print_avatars($member_ids) {

		$extrafooter_random             = woffice_get_settings_option( 'extrafooter_random' );

		if($member_ids && apply_filters('woffice_use_transient_in_extrafooter', true)) {
			if ( $extrafooter_random == "yep" ) {
				shuffle( $member_ids );
			}

			foreach($member_ids as $id ) {
				print get_avatar( $id, 80 );
			}
			return;
		}

		$member_ids = array();
		$extrafooter_avatar_only        = woffice_get_settings_option( 'extrafooter_avatar_only' );
		$extrafooter_repetition_allowed = woffice_get_settings_option( 'extrafooter_repetition_allowed' );

		// GET USERS
		$woffice_wp_users        = get_users( array( 'fields' => array( 'ID', 'user_url' ) ) );
		$users_already_displayed = array();

		// If is set random faces, shuffle array of users
		if ( $extrafooter_random == "yep" ) {
			shuffle( $woffice_wp_users );
		}

		//Do this for each user, max 100 because are not displayed more than 100 users in the extrafooter
		//$j is max counter; $x is users array index
		for ( $x = 0, $j = 0; $j < 99 && $x < count( $woffice_wp_users ); $x ++ ) {

			$excluded_users = apply_filters( 'woffice_exclude_user_ids_from_extrafooter', array() );

			//Excluded users from extrafoter
			if ( in_array( $woffice_wp_users[ $x ]->ID, $excluded_users ) ) {
				continue;
			}

			//If repetition of faces are not allowed, display only if is not already displayed
			if ( $extrafooter_repetition_allowed == 'yep' || ! in_array( $woffice_wp_users[ $x ]->ID, $users_already_displayed ) ) {
				if ( $extrafooter_avatar_only == "yep" ) {
					if ( validate_gravatar( $woffice_wp_users[ $x ]->ID ) ) {
						print get_avatar( $woffice_wp_users[ $x ]->ID, 80 );
						array_push( $users_already_displayed, $woffice_wp_users[ $x ]->ID );
						array_push( $member_ids, $woffice_wp_users[ $x ]->ID );
						$j ++;
					}
				} else {
					print get_avatar( $woffice_wp_users[ $x ]->ID, 80 );
					array_push( $users_already_displayed, $woffice_wp_users[ $x ]->ID );
					array_push( $member_ids, $woffice_wp_users[ $x ]->ID );
					$j ++;
				}
			}
		}

		//If repetitive faces are allowed and it need more faces to reach 100, than get more faces randomly from already inserted user
		if ( $extrafooter_repetition_allowed == 'yep' && $j < 99 ) {
			if ( ! empty( $users_already_displayed ) ) {
				for ( $x = 0; $x < ( 99 - $j ); $x ++ ) {
					$woffice_wp_selected = $users_already_displayed[ array_rand( $users_already_displayed ) ];
					print get_avatar( $woffice_wp_selected, 80 );
					array_push( $member_ids, $woffice_wp_selected );
				}
			}
		}

		set_transient( 'woffice_extrafooter_member_ids', $member_ids, 86400 );
	}
}

if(!function_exists('woffice_get_string_between')) {
    /**
     * Get the content of a string between two substrings
     * @param string $string
     * @param string $start
     * @param string $end
     * @return string
     */
    function woffice_get_string_between($string, $start, $end)
    {
        $string = ' ' . $string;
        $ini = strpos($string, $start);
        if ($ini == 0) return '';
        $ini += strlen($start);
        $len = strpos($string, $end, $ini) - $ini;
        return substr($string, $ini, $len);
    }
}

if(!function_exists('woffice_current_is_admin')) {
    /**
     * Check if the current user is an administrator
     * @return bool
     */
    function woffice_current_is_admin()
    {
        return (current_user_can('administrator')) ? true : false;
    }
}

if(!function_exists('woffice_check_meta_caps')) {
    /**
     * Check if meta caps override Woffice settings by frontend
     * @param null|string $post_type
     * @return bool
     */
    function woffice_check_meta_caps($post_type = null) {

        //TODO when add here new post type available to manage by meta caps, they have to be added also in woffice_frontend_proccess(), around line 115
        if (!is_null($post_type) && ($post_type == 'wiki' || $post_type == 'post'))
            return woffice_get_settings_option('override_' . $post_type . '_by_caps', false);
        else
            return false;
    }
}

if(!function_exists('woffice_get_slug_for_meta_caps')) {
    /**
     * Return the corresponding plural slug used in meta capabilities of each post type
     * @param null|string $post_type
     * @return string
     */
    function woffice_get_slug_for_meta_caps($post_type = null) {

        switch ($post_type) {
            case "wiki":
                return 'wikies';
            case 'post':
                return 'posts';
            default:
                return '';
        }

    }
}

if(!function_exists('woffice_get_children_count')) {
    /**
     * Return the number of posts inside a category (recursively)
     *
     * @param $category_id
     * @param $taxonomy
     * @return int
     */
    function woffice_get_children_count($category_id, $taxonomy, $excluded = array()){
        $cat = get_category($category_id);
        $count = (int) $cat->count;
        $args = array(
            'child_of' => $category_id,
            'exclude' => $excluded
        );
        $tax_terms = get_terms($taxonomy,$args);
        foreach ($tax_terms as $tax_term) {
            $count += $tax_term->count ;
        }
        return $count;
    }
}

if(!function_exists('woffice_send_user_registration_email')) {
    /**
     * Send an email to registered user that confirm the complete registration
     *
     * @param int $user_id Id of registered user
     */
    function woffice_send_user_registration_email($user_id){

        $register_new_user_email = woffice_get_settings_option('register_new_user_email');
        $login_custom = woffice_get_settings_option('login_custom');
        if($register_new_user_email != 'yep' || $login_custom != 'yep')
            return;

        $site_name = get_option( 'blogname' );
        $admin_email = get_option( 'admin_email' );

        $user = get_userdata( $user_id );

        //Body
        $message = sprintf(esc_html__( 'Your registration on %s is completed.', 'woffice' ), $site_name) . "\r\n\r\n";
        $message .= esc_html__('Login url:', 'woffice'). ' ' . wp_login_url()."\r\n";
        $message .= esc_html__('Username:', 'woffice') . ' ' . $user->user_login ."\r\n";
        $message .= esc_html__('Password: The password chosen during the registration', 'woffice');

        $message = apply_filters( 'woffice_user_registration_message_body', $message, $user );

        //Subject
        $subject = esc_html__( 'Your registration is completed', 'woffice' );
        $subject = apply_filters( 'woffice_user_registration_message_subject', $subject, $user );

        //Headers
        $headers = array(
            "From: \"{$site_name}\" <{$admin_email}>\n",
            "Content-Type: text/plain; charset=\"" . get_option( 'blog_charset' ) . "\"\n",
        );
        $headers = apply_filters( 'woffice_user_registration_message_headers', $headers );

        wp_mail( $user->user_email, $subject, $message, $headers );
    }
}

if(!function_exists('woffice_get_name_to_display')) {
    /**
     * Get the name to user name to display according with Woffice Buddypress Settings
     * @param null|object|int $user
     * @return string
     */
    function woffice_get_name_to_display($user = null)
    {
        if (is_null($user)) {
            $user_info = wp_get_current_user(array('fields' => array('ID', 'user_firstname', 'user_login', 'user_nicename', 'display_name')));
        } elseif (is_object($user)) {
            $user_info = $user;
        } elseif (is_numeric($user)) {
            $user_info = get_userdata($user);
        }
        $buddy_directory_name = woffice_get_settings_option('buddy_directory_name');

        if($buddy_directory_name == "name" && !empty($user_info->user_firstname) && !empty($user_info->user_lastname)){
            $display = $user_info->user_firstname .' '. $user_info->user_lastname;
        } else {
            $display = $user_info->user_login;
        }

        return apply_filters('woffice_get_name_to_display', $display, $user_info);
    }
}

if(!function_exists('woffice_adjust_brightness')){
    /**
     * Take a color and make it brighter or darker
     * @link http://stackoverflow.com/questions/3512311/how-to-generate-lighter-darker-color-with-php
     * @author Torkil Johnsen
     * @return string
     */
    function woffice_get_adjust_brightness($hex, $steps) {
        // Steps should be between -255 and 255. Negative = darker, positive = lighter
        $steps = max(-255, min(255, $steps));

        // Normalize into a six character long hex string
        $hex = str_replace('#', '', $hex);
        if (strlen($hex) == 3) {
            $hex = str_repeat(substr($hex,0,1), 2).str_repeat(substr($hex,1,1), 2).str_repeat(substr($hex,2,1), 2);
        }

        // Split into three parts: R, G and B
        $color_parts = str_split($hex, 2);
        $return = '#';

        foreach ($color_parts as $color) {
            $color   = hexdec($color); // Convert to decimal
            $color   = max(0,min(255,$color + $steps)); // Adjust color
            $return .= str_pad(dechex($color), 2, '0', STR_PAD_LEFT); // Make two char hex code
        }

        return $return;
    }
}

if(!function_exists('woffice_get_navigation_state')) {
    /**
     * Return the state of the navigation default state. Return true if it is showed and false if it is hidden
     * @return bool
     */
    function woffice_get_navigation_state() {
        $menu_default = woffice_get_settings_option('menu_default');
        $nav_opened_state = (isset($_COOKIE['Woffice_nav_position']) && $_COOKIE['Woffice_nav_position'] == 'navigation-hidden' || $menu_default == "close") ? false : true;
        return $nav_opened_state;
    }
}

if(!function_exists('woffice_get_navigation_class')) {
    /**
     * Return the class for the navigation default state. It compare the cookies and the them options
     * @return string
     */
    function woffice_get_navigation_class() {
        $nav_opened_state = woffice_get_navigation_state();
        return (!$nav_opened_state) ? ' navigation-hidden ' : '';
    }
}

if(!function_exists('woffice_redirect_to_login')) {
    /**
     * Redirect to login page and preserve the previous page url for a potential redirect
     *
     * @param string $param the parameter to add to login page (For instance: 'type=lost-password&foo=bar')
     * @param bool $param $disable_redirect_to
     */
    function woffice_redirect_to_login( $param = '', $disable_redirect_to = true ) {

        if ( ! $disable_redirect_to ) {
            //Get the previous url from parameter if it is already stored
            $redirect_to = ( isset( $_GET['redirect_to'] ) && ! empty( $_GET['redirect_to'] ) ) ? urldecode( $_GET['redirect_to'] ) : null;

            //If there is not a redirect url already stored then get the current url
            if ( is_null( $redirect_to ) ) {
                $http        = ( ! empty( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443 ) ? "https://" : "http://";
                $redirect_to = $http . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
            }

            $redirect_to = '?redirect_to=' . urlencode( $redirect_to );
        } else {
            $redirect_to = '';
        }

        //Get the login url and add the redirect url as parameter
        $login_page_slug = woffice_get_login_page_name();
        $login_page      = home_url( '/' . $login_page_slug . '/' ) . $redirect_to;

        //Add other parameters if they are present
        $param = ( empty( $param ) ) ? '' : '&' . $param;
        if ( ! empty( $param ) && empty( $redirect_to ) ) {
            $param = '?' . $param;
        }

        //Redirect
        wp_redirect( $login_page . $param );

    }
}

if(!function_exists('woffice_get_login_page_name')) {
    function woffice_get_login_page_name(){
        /* We fetch the data from the settings */
        $the_login_page = woffice_get_settings_option('login_page');
        if (!empty($the_login_page)) {
            /* We have the ID we need the name */
            $login_post = get_post($the_login_page[0]);
            $slug = $login_post->post_name;
            return $slug;
        } else {
            return 'login';
        }

    }
}

if(!function_exists('woffice_unyson_is_required')) {
    /**
     * Function to inform the user to enable Unyson before using WOffice...
     * @since 2.1.0.1
     */
    function woffice_unyson_is_required(){

        ?>

        <div id="woffice_unyson_required">

            <style type="text/css">
                #woffice_unyson_required{
                    position: fixed;
                    left: 0;
                    top: 0;
                    width: 100%;
                    height: 100%;
                    z-index: 1000;
                    background: #ffffff;
                    overflow-y: scroll;
                }
                #woffice_unyson_required div.text-center{
                    text-align: center;
                    margin-top: 10%;
                    padding: 20px 80px;
                }
                #woffice_unyson_required div.text-center i{
                    font-size: 200px;
                    color: #5c84a2;
                }
                #woffice_unyson_required div.text-center{
                    font-family: "Helvetica Neue", "Arial", sans-serif;
                }
                #woffice_unyson_required div.text-center h1{
                    font-weight: lighter;
                    font-size: 48px;
                }
                #woffice_unyson_required div.text-center h3{
                    font-weight: bold;
                    font-size: 24px;
                }
                #woffice_unyson_required div.text-center a{
                    color: #5c84a2;
                }
            </style>

            <div class="text-center">
                <i class="fa fa-cogs"></i>
                <?php if(woffice_current_is_admin()) : ?>
                    <h1><?php _e('Almost here, you need to active the Woffice framework (Unyson).', 'woffice'); ?></h1>
                    <h3>
                        <?php _e('You can enable Unyson', 'woffice'); ?>
                        <a href="<?php echo admin_url('themes.php?page=tgmpa-install-plugins&plugin_status=activate'); ?>"><b><?php _e('here', 'woffice'); ?></b></a>
                         <?php _e('or follow the documentation', 'woffice'); ?>
                        <a href="//woffice.io/documentation/"><b><?php _e('here', 'woffice'); ?></b></a>
                        <?php _e('where all is explained with details.', 'woffice'); ?>
                    </h3>
                    <p>
                        <?php _e('Why ? Woffice is based on Unyson framework to enhance Wordpress features and to provide a much better interface as well as better performances. We use it to build Woffice extensions and all its settings so you can customize it as you like. Feel free to get in touch with us if you\'ve any question.', 'woffice'); ?>
                    </p>
                <?php else : ?>
                    <h1><?php _e('Site is under construction, thanks for your patience...', 'woffice'); ?></h1>
                <?php endif; ?>
            </div>

        </div>

        <?php

    }
}

if(!function_exists('woffice_is_current_page_using_blank_template')) {
    /**
     * Check if the page is using the blank template or not
     * @return bool
     */
	function woffice_is_current_page_using_blank_template() {
		$is_blank_page = is_page_template('page-templates/blank-page.php');
		$is_activation_page = (function_exists('bp_is_activation_page') && bp_is_activation_page());
		
		return ($is_blank_page || $is_activation_page);
	}
}

if(!function_exists('woffice_online_users')) {
    /**
     * Displaying the number of the online users
     * Note used so far
     */
    function woffice_online_users()
    {
        global $bp;
        if (bp_has_members('type=online')):
            echo '<li><span class="has-online"></span> <strong>' . bp_has_members('type=online') . '</strong></li>';
        else :
            echo '<li><span class="has-online"></span> <strong>0</strong></li>';
        endif;
    }
}

if(!function_exists('woffice_current_time')) {
    /**
     * Return the current time,
     * used to be in the user menu
     *
     */
    function woffice_current_time()
    {
        $blogtime = current_time('mysql');
        echo $blogtime;
    }
}

if(!function_exists('woffice_is_buddypres_component_active')) {
	/**
	 * Check if a given buddypress componenet is active
	 *
	 * @param $componenet
	 *
	 * @return bool
	 */
	function woffice_is_buddypres_component_active($componenet) {
		return (function_exists('bp_is_active') && bp_is_active( $componenet ));
	}
}

if(!function_exists('woffice_get_users_ids_by_xprofile_fields')) {
	/**
	 * Return an aray of ids of members that fit the search criterias.
	 *
	 * Example of Search Criterias:
	 * array (
	 *        [0] => array (
	 *            [key] => '8268'
	 *            [value] => 'Rome'
	 *            [value_max] => ''
	 *            )
	 *        [1] => array (
	 *            [key] => '8264'
	 *            [value] => '20'
	 *            [value_max] => '50'
	 *        )
	 *    )
	 *
	 * @param $fields
	 *
	 * @return array|string
	 */
	function woffice_get_users_ids_by_xprofile_fields( $fields ) {

		if ( empty( $fields ) ) {
			return '';
		}

		global $wpdb;
		$query = "SELECT user_id FROM " . $wpdb->prefix . "bp_xprofile_data";

		$where_added = false;
		foreach ( $fields as $field ) {
			if ( ! isset( $field['key'] ) || ! isset( $field['value'] ) ) {
				continue;
			}

			//$field['compare'] = ( isset( $field['compare'] ) && ( $field['compare'] == 'LIKE' ) ) ? $field['compare'] : '=';

			//$field_id = xprofile_get_field_id_from_name( $field['key'] );
			$field_id = $field['key'];

			$field_object = xprofile_get_field( $field['key'] );

			if ( ! empty( $field_id ) ) {

				//Add WHERE only one time
				if ( ! $where_added ) {
					$query .= ' WHERE';
					$where_added = true;
				} else {
					$query .= ' OR';
				}


				$query .= " (field_id = '" . $field_id . "'";

				if ( (string) $field['value'] != '' ) {
					switch ( $field_object->type ) {
						case 'selectbox':
							$query .= " AND value = '" . $field['value'] . "'";
							break;
						case 'number':
							if ( ! empty( $field['value'] ) ) {
								$query .= " AND value >= '" . $field['value'] . "'";
							}
							if ( ! empty( $field['value_max'] ) ) {
								$query .= " AND value <= '" . $field['value_max'] . "'";
							}
							break;
						default:
							$query .= " AND value LIKE '%" . $field['value'] . "%'";
					}
				}

				$query .= ")";
			}


		}

		//fw_print($query;)

		$custom_ids = $wpdb->get_col( $query );

		return $custom_ids;

	}
}
