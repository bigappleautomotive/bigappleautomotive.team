<?php
/**
 * Class Woffice_Security
 * This class handles the redirection process in Woffice
 * As well as the custom login page hooks / actions
 * @since 2.1.3
 * @author Alkaweb
 */
if( ! class_exists( 'Woffice_Security' ) ) {
    class Woffice_Security
    {

        /**
         * Woffice_Security constructor
         */
        public function __construct()
        {
            add_action( 'template_redirect', array($this,'redirect_user'));
            add_action( 'init', array($this,'redirect_login_page'));
            $login_custom = woffice_get_settings_option( 'login_custom' );
            if ( $login_custom != "nope" ) {
                add_action( 'wp_login_failed', array($this, 'login_failed'));
                add_filter( 'authenticate', array($this, 'filter_verify_username_password'), 1, 3);
                add_action( 'admin_head', array($this,'custom_auth_css'));
                add_action( 'after_switch_theme', array($this,'create_login_page'));
                add_action( 'fw_settings_form_saved', array($this,'create_login_page'));
                add_action( 'wp_logout', array($this,'logout_page'));
                add_action( 'login_form_lostpassword', array($this,'password_lost'));
                add_action( 'login_form_lostpassword', array($this,'redirect_to_custom_lostpassword'));
                //add_action('password_reset', 'woffice_lost_password_redirect');
            }
        }

        /**
         * We create the login page
         * If it doesn't exist yet
         */
        public function create_login_page(){
            // CREATE THE LOGIN PAGE
            global $wpdb;
            $table_name = $wpdb->prefix . 'posts';
            $check_page = $wpdb->get_row("SELECT post_name FROM ".$table_name." WHERE post_name = 'login'", 'ARRAY_A');
            if(empty($check_page)) {
                $prop_page = array(
                    'ID' 			=> '',
                    'post_title'    => 'Login',
                    'post_content'  => '',
                    'post_excerpt'  => '',
                    'post_name' => 'login',
                    'post_type' 	=> 'page',
                    'post_status'   => 'publish',
                    'post_author'   => 1,
                    'page_template' => 'page-templates/login.php'
                );
                wp_insert_post($prop_page);
            }
        }

        /**
         * We redirect the user
         * This is the most important function for the security
         * We check whether the user is allowed or not
         * That's also the function behind the redirection loop issue
         */
        public function redirect_user()
        {
            // We get the site status
            $public = woffice_get_settings_option( 'public' );
            // If site is public & user isn't logged we'll check for the pages
            if ( $public == "nope" && ! is_user_logged_in() ) {

                // Redirect constant
                //$redirect = false;

                // We get the login page to avoid infinite loop :
                $login_page_slug = woffice_get_login_page_name();
                if ( ! is_page( $login_page_slug ) ) {

                    // We need it to know if tge first one is condition is checked (Buddypress)
                    $buddypress_check_passed = false;

                    /*
                     * If it's a 404 that means it could be a redirection issue (loop)
                     * It can be fixed by refreshing the .htaccess file
                     */
                    if(is_404()) {
                        flush_rewrite_rules();
                    }

                    // We check for Buddypress components :
                    if ( function_exists( "woffice_is_user_allowed_buddypress" ) ) {
                        // We run it only for Buddypress pages
                        if ( is_buddypress() ) {
                            $buddypress_check = woffice_is_user_allowed_buddypress( "redirect" );
                            if ( $buddypress_check == false ) {
                                wp_redirect( esc_url( home_url( '/wp-login.php' ) ) );
                                exit();
                            } else {
                                $buddypress_check_passed = true;
                            }
                        }
                    }

                    if ( $buddypress_check_passed != true ) {

                        // We check for excluded page - Check if there is some pages that need to be public
                        $excluded_pages       = woffice_get_settings_option( 'excluded_pages' );
                        $the_pages_tmp        = array();
                        $it_is_blog_component = false;
                        if ( ! empty( $excluded_pages ) ) {

                            // We check for the Blog page :
                            $page_for_posts    = get_option( 'page_for_posts' );
                            $ID_page_for_posts = ( ! empty( $page_for_posts ) ) ? $page_for_posts : 0;
                            // If the blog page is in the excluded pages && it's this page:
                            if ( in_array( $ID_page_for_posts, $excluded_pages ) && $ID_page_for_posts != 0 && ( is_home() || is_singular( 'post' ) ) ) {
                                $it_is_blog_component = true;
                            }

                            // We fill the array
                            foreach ( $excluded_pages as $page ) {
                                $the_pages_tmp[] = $page;
                            }

                        } else {
                            $the_pages_tmp = array( "-1" );
                        }

                        // We check for the Woocommerce products :
                        if ( function_exists( 'is_woocommerce' ) ) {
                            $products_public = woffice_get_settings_option( 'products_public' );
                            if ( $products_public == "yep" && is_product() ) {
                                $allowed_product = true;
                            } else {
                                $allowed_product = false;
                            }
                        } else {
                            $allowed_product = false;
                        }

                        $filter_applied = apply_filters('woffice_redirect_user_additional_check', true);

                        // If it's not one of the excluded pages AND Not the blog page, we redirect :
                        if ( ! is_page( $the_pages_tmp ) && $it_is_blog_component == false && $allowed_product == false && $filter_applied) {
                            // We check for custom login page

                            do_action('woffice_before_redirect_unallowed_user_to_login');

                            $login_custom = woffice_get_settings_option( 'login_custom' );
                            if ( $login_custom != "nope" ) {

                                woffice_redirect_to_login( '', false );
                                exit();
                            } else {
                                wp_redirect( esc_url( home_url( '/wp-login.php' ) ) );
                                exit();
                            }
                        }

                    }

                }

            }
        }

        /**
         * Redirect the user to the login page
         */
        public function redirect_login_page()
        {
            $login_custom = woffice_get_settings_option( 'login_custom' );
            if ( $login_custom != "nope" ) :

                $page_viewed = basename( $_SERVER['REQUEST_URI'] );

                if ( $page_viewed == "wp-login.php" && $_SERVER['REQUEST_METHOD'] == 'GET' ) {
                    woffice_redirect_to_login();
                    exit;
                }

            endif;
        }

        /**
         * On login fail, we redirect to the custom login page
         */
        public function login_failed()
        {
            woffice_redirect_to_login( 'login=failed' );
            exit;
        }

        /**
         * Filter to redirect on login password or username are empty
         * @param $user
         * @param $username
         * @param $password
         */
        public function filter_verify_username_password( $user, $username, $password ) {
            if ( $username == "" || $password == "" ) {
                woffice_redirect_to_login( 'login=empty' );
                exit;
            }
        }


        /**
         * Logout redirection
         */
        public function logout_page()
        {
            woffice_redirect_to_login( 'login=false' );
            exit;
        }

        /**
         * Custom CSS for the login popup on Wordpress admin
         */
        public function custom_auth_css()
        {
            echo '<style type="text/css">#wp-auth-check-wrap #wp-auth-check{margin: 0 0 0 -45%;width: 90%;}</style>';
        }

        /**
         * Handles the lost password action
         */
        public function password_lost()
        {
            $login_rest_password = woffice_get_settings_option( 'login_rest_password' );
            if ($login_rest_password == "yep" && 'POST' == $_SERVER['REQUEST_METHOD'] ) :
                $errors          = retrieve_password();
                $login_page_slug = woffice_get_login_page_name();
                $login_page      = home_url( '/' . $login_page_slug . '/' );
                if ( is_wp_error( $errors ) ) {
                    // Errors found
                    $redirect_url = $login_page . "?type=lost-password";
                    $redirect_url = add_query_arg( 'errors', join( ',', $errors->get_error_codes() ), $redirect_url );
                } else {
                    // Email sent
                    $redirect_url = $login_page;
                    $redirect_url = add_query_arg( 'checkemail', 'confirm', $redirect_url );
                }

                wp_redirect( $redirect_url );
                exit;
            endif;
        }

        /**
         * Handling the redirection to the custom lost password page
         */
        public function redirect_to_custom_lostpassword()
        {
            $login_rest_password = woffice_get_settings_option( 'login_rest_password' );
            if ($login_rest_password == "yep" && 'GET' == $_SERVER['REQUEST_METHOD'] ) :

                if ( is_user_logged_in() ) {
                    wp_redirect( home_url() );
                    exit;
                }
                woffice_redirect_to_login( 'type=lost-password' );
                exit;

            endif;
        }

        /**
         * Redirect to home page after lost password action
         */
        public function lost_password_after_redirect() {
            wp_redirect( home_url() );
            exit;
        }

    }
}

/**
 * Let's fire it :
 */
new Woffice_Security();



