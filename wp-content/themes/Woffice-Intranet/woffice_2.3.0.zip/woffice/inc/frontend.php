<?php 
/**
 * FRONTEND FUNCTIONS
 * @internal
 * You'll find here all the functions we are using for the front end edit so the files look better
 */

if(!function_exists('woffice_role_allowed')) {
	/**
	 * Does the user can create in frontend ?
	 * -
	 * This function check if the current member can create a post according to the options set in the Theme Settings
	 *
	 * @param array $users_from_options is an array of users from the theme settings
	 * @param null|string $post_type the type of the post the the function have to check the permissions
	 *
	 * @return bool
	 */
	function woffice_role_allowed( $users_from_options, $post_type = null ) {
		/* If the users is not logged we reeturn false */
		if ( ! is_user_logged_in() ) {
			return false;
		}

		//Check if woffice permissions settings are overrited by meta caps
		$use_meta_caps = woffice_check_meta_caps( $post_type );

		if ( $use_meta_caps ) {
			$slug   = woffice_get_slug_for_meta_caps( $post_type );
			$prefix = ( $post_type != 'post' ) ? 'woffice_' : '';

			return current_user_can( $prefix . 'edit_' . $slug );
		} else {
			/* We force the arg to be an array */
			if ( is_array( $users_from_options ) == false ) {
				$users_from_options = array( $users_from_options );
			}

			/* We get the current user data */
			$user          = wp_get_current_user();
			$the_user_role = (array) $user->roles;

			$role_intersect = array_intersect( $the_user_role, $users_from_options );

			/* We check if it's in the array, OR if it's the administrator  */

			return ( ! empty( $role_intersect ) || woffice_current_is_admin() );
		}

	}
}

if(!function_exists('woffice_frontend_set_terms')) {
	/**
	 * Helper, set the terms to a post type with the frontend values
	 * -
	 * $post_values : Values selected in the frontend ($_POST) it's an array
	 * $type : the post type
	 * $post_id : The ID of the new post
	 */
	function woffice_frontend_set_terms( $post_values, $type, $post_id ) {

		/* Categories name */
		if ( $type == "project" ) {
			$term_name = "project-category";
		} elseif ( $type == "wiki" ) {
			$term_name = "wiki-category";
		} elseif ( $type == "directory" ) {
			$term_name = "directory-category";
		} else {
			$term_name = "category";
		}

		$term_array = array();

		foreach ( $post_values as $category ) {

			if ( $category != "no-category" ) {

				if ( $type == "post" ) {
					$type_catgeory_object = get_category_by_slug( $category );
				} else {
					$type_catgeory_object = get_term_by( 'slug', $category, $term_name );
				}

				//fw_print($project_catgeory_object);
				$term_array[] = $type_catgeory_object->term_id;

			}

		}
		$value_set = wp_set_post_terms( $post_id, $term_array, $term_name );

		if ( $type == "project" ) {
			$post_object = get_post( $post_id );
			woffice_groups_sync_members( $post_id, $post_object, false );
			//do_action("save_post", $post_id, $post_object, false);
		}

	}
}

if(!function_exists('woffice_frontend_proccess')) {
	/**
	 * Processing the data sent by the form
	 * -
	 * This function process the data from the FORM (see next function)
	 *
	 * @param string $type is the kind of post (project, wiki, directory or post)
	 * @param bool $is_shortcode we can't redirect in the shortcode
	 *
	 * @return bool
	 */
	function woffice_frontend_proccess( $type, $is_shortcode = false ) {

		global $post;

		/* If there is no title */
		$has_error        = false;
		$post_title_error = '';

		/* We first check that the form was submitted */
		if ( isset( $_POST['submitted'] ) && isset( $_POST['post_nonce_field'] ) && wp_verify_nonce( $_POST['post_nonce_field'], 'post_nonce' ) ) {

			/* We check that title isn't empty */
			if ( trim( $_POST['post_title'] ) === '' ) {

				$post_title_error = __( 'Please enter a title.', 'woffice' );
				$has_error        = true;

			} else {

				/* Get the post status when submitted */
				$use_meta_caps = woffice_check_meta_caps( $type );
				if ( $use_meta_caps && ( $type == 'wiki' || $type == 'post' ) ) {
					$slug           = woffice_get_slug_for_meta_caps( $type );
					$prefix         = ( $type != 'post' ) ? 'woffice_' : '';
					$frontend_state = ( current_user_can( $prefix . 'publish_' . $slug ) ) ? 'publish' : 'draft';
				} else {
					$frontend_state = woffice_get_settings_option( 'frontend_state' );
				}

				$frontend_state = apply_filters('woffice_frontend_state', $frontend_state);

				/* For all posts */
				if ( $type != "directory" ) {
					$post_information = array(
						'post_title'   => wp_strip_all_tags( $_POST['post_title'] ),
						'post_content' => $_POST['post_content'],
						'post_status'  => $frontend_state,
						'post_type'    => $type,
					);
				} else {
					$post_information = array(
						'post_title'   => wp_strip_all_tags( $_POST['post_title'] ),
						'post_excerpt' => $_POST['post_content'],
						'post_status'  => $frontend_state,
						'post_type'    => $type,
					);
				}
				/* We create the Post */
				$post_id = wp_insert_post( $post_information );


				if ( $type == 'wiki' ) {
					/* if it's for a WIKI POST */

					/*We set the term*/
					if ( isset( $_POST['wiki_category'] ) ) {
						woffice_frontend_set_terms( $_POST['wiki_category'], $type, $post_id );
					}

					//By default, the "everyone_edit" field is true by frontend
					fw_set_db_post_option( $post_id, 'everyone_edit', true );

				} elseif ( $type == 'project' ) {
					/* if it's for a PROJECT POST */

					
					/*We set the term*/
					if ( isset( $_POST['project_category'] ) ) {
						woffice_frontend_set_terms( $_POST['project_category'], $type, $post_id );
					}

				} elseif ( $type == 'directory' ) {
					/* if it's for a DIRECTORY POST */

					/*We set the term*/
					if ( isset( $_POST['directory_category'] ) ) {
						woffice_frontend_set_terms( $_POST['directory_category'], $type, $post_id );
					}

					/* We get the custom DATA for the item */
					$item_button_icon = ( ! empty( $_POST['item_button_icon'] ) ) ? $_POST['item_button_icon'] : "";
					$item_button_text = ( ! empty( $_POST['item_button_text'] ) ) ? $_POST['item_button_text'] : "";
					$item_button_link = ( ! empty( $_POST['item_button_link'] ) ) ? $_POST['item_button_link'] : "";

					if ( ! empty( $_POST['item_location_lng'] ) && ! empty( $_POST['item_location_lat'] ) ) {
						$location = array(
							'location'    => '',
							'venue'       => '',
							'address'     => '',
							'city'        => '',
							'state'       => '',
							'country'     => '',
							'zip'         => '',
							'coordinates' => array(
								'lat' => $_POST['item_location_lat'],
								'lng' => $_POST['item_location_lng'],
							)
						);
					} else {
						$location = "";
					}

					/* We save the values */
					$directory_data = array(
						'item_location'    => $location,
						'item_button_text' => $item_button_text,
						'item_button_icon' => $item_button_icon,
						'item_button_link' => $item_button_link,
					);
					add_post_meta( $post_id, 'fw_options', $directory_data );

				} else {
					/* if it's for a POST POST */

					/*We set the term*/
					if ( isset( $_POST['blog_category'] ) ) {
						woffice_frontend_set_terms( $_POST['blog_category'], $type, $post_id );
					}

					if ( woffice_current_is_admin() ) {
						if ( isset( $_POST['everyone_edit'] ) && $_POST['everyone_edit'] == 'yes' ) {
							fw_set_db_post_option( $post_id, 'everyone_edit', true );
						} else {
							fw_set_db_post_option( $post_id, 'everyone_edit', false );
						}
					} else //By default, the "everyone_edit" field is true by frontend for non admins
					{
						fw_set_db_post_option( $post_id, 'everyone_edit', true );
					}
				}

				if ( $type != 'wiki' && $type != 'project' ) {
					/* We add the thubnail image */
					if ( $_FILES["post_thumbnail"]["error"] == 0 ) {
						$attach_id = 0;
						require_once( ABSPATH . "wp-admin" . '/includes/image.php' );
						require_once( ABSPATH . "wp-admin" . '/includes/file.php' );
						require_once( ABSPATH . "wp-admin" . '/includes/media.php' );
						if ( $_FILES ) {
							foreach ( $_FILES as $file => $array ) {
								if ( $_FILES[ $file ]['error'] !== UPLOAD_ERR_OK ) {
									//return "upload error : " . $_FILES[$file]['error'];
									fw_print( "upload error : " . $_FILES[ $file ]['error'] );
								}
								$attach_id = media_handle_upload( $file, $post_id );
							}
						}
						if ( $attach_id > 0 ) {
							//and if you want to set that image as Post  then use:
							update_post_meta( $post_id, '_thumbnail_id', $attach_id );
						}
					}
				}

			}

			/* What the function is returning */
			if ( $has_error == true ) {
				return false;
			} else {

				do_action('woffice_frontend_process_completed_success', $post_id, get_post($post_id));

				if($is_shortcode == false) {
					/* We refresh to the created post */
					wp_redirect(get_permalink($post_id));
				} else{
					return $post_id;
				}
			}

		}
	}
}

if(!function_exists('woffice_frontend_render')) {
	/**
	 * Render form HTML
	 * -
	 * This function displays HTML form for the frontend edit
	 * $type is the kind of post (project, wiki or post)
	 */
	function woffice_frontend_render( $type, $everything_fine, $child_of = 0 ) {

		/* If a post has been created and we're in the shortcode : */
		if(is_int($everything_fine) && $everything_fine != 0){
			echo '<div class="infobox fa fa-check-circle-o" style="background-color: #3cb500;">';
				echo '<span class="infobox-head">'.__('Created !', 'woffice').'</span>';
				echo '<p>'.__('Check it out :', 'woffice').' <a href="'.get_the_permalink($everything_fine).'">'.get_the_title($everything_fine).'</a></p>';
			echo'</div>';
		}

		$type = ( $type == 'post' ) ? 'blog' : $type;
		/* First the loader */
		echo '<!-- LOADER -->
	<div id="' . $type . '-loader" class="intern-padding woffice-loader">
		<i class="fa fa-spinner"></i>
	</div>';

		/* Form Wrapper */
		echo '<!-- CREATE NEW ARTICLE-->';
		echo '<div id="' . $type . '-create" class="intern-padding">';
		/* The FORM */
		if ( $type == "blog" ) {
			$the_option = get_option( 'show_on_front' );
			if ( $the_option == 'page' ) {
				$blog_page = get_option( 'page_for_posts' );
				if ( empty( $blog_page ) ) {
					$pages     = get_pages( array(
						'meta_key'   => '_wp_page_template',
						'meta_value' => 'page-templates/blog.php'
					) );
					$blog_page = $pages[0]->ID;
				}
				$form_url = get_permalink( $blog_page );
			} else {
				$form_url = get_site_url() . '/';
			}
		} else {
			$form_url = get_the_permalink();
		}
		?>

		<!-- THE FORM -->
		<?php $form_extra = ( $type == "blog" || $type == "directory" ) ? ' enctype="multipart/form-data"' : ''; ?>
		<form action="<?php echo esc_url($form_url); ?>" id="primaryPostForm" method="POST" <?php echo $form_extra; ?> >

			<?php if ( $type == 'project' && ! current_user_can( "edit_posts" ) ) { ?>

				<div class="infobox fa fa-cogs" style="background-color: #7B7B7B;">
					<span class="infobox-head"><?php _e( "Information", "woffice" ); ?></span>
					<p><?php _e( "You'll only find here basic settings for the projects, for more settings please contact an user with author right.", "woffice" ); ?></p>
				</div>

			<?php } ?>

			<p>
				<?php /* Title Label */
				if ( $type == "project" ) {
					$title_label = __( 'Project\'s Title:', 'woffice' );
				} elseif ( $type == "directory" ) {
					$title_label = __( 'Item\'s Title:', 'woffice' );
				} else {
					$title_label = __( 'Article\'s Title:', 'woffice' );
				} ?>
				<label for="post_title"><?php echo $title_label; ?></label>
				<input type="text" name="post_title" id="post_title" class="required" required/>
			</p>

			<?php if ( $everything_fine === false ) { ?>
				<div id="message" class="infobox" style="background-color: #DE1717;">
					<?php _e( "Please enter a title", "woffice" ); ?>
				</div>
			<?php } ?>


			<?php /* if it's for a WIKI POST */
			if ( $type == 'wiki' ) { ?>

				<?php
				// SEARCH FOR WIKI CATEGORIES
				$terms = get_terms( 'wiki-category', array( 'hide_empty' => false, 'child_of' => $child_of ) );
				if ( $terms ) : ?>
					<p>
						<label for="wiki_category"><?php _e( 'Article\'s Category:', 'woffice' ); ?></label>
						<?php // DROPDOWN LIST
						echo '<select multiple="multiple" name="wiki_category[]" class="postform form-control">';
						echo '<option value="no-category">' . __( "No category", "woffice" ) . '</option>';
						foreach ( $terms as $term ) {
							printf( '<option value="%s">%s</option>', esc_attr( $term->slug ), esc_html( $term->name ) );
						}
						echo '</select>'; ?>
					</p>
				<?php endif; ?>


			<?php } elseif ( $type == 'project' ) {
				/* if it's for a PROJECT POST */
				?>

				<div class="row">
					<div class="col-md-6">
						<p>
							<label for="project_start"><?php _e( 'Project\'s starting date:', 'woffice' ); ?></label>
							<input type="text" name="project_start" id="project_start" class="datepicker"
								   placeholder="<?php echo date( 'd-m-Y' ); ?>"/>
						</p>
					</div>
					<div class="col-md-6">
						<p>
							<label for="project_end"><?php _e( 'Project\'s ending date:', 'woffice' ); ?></label>
							<input type="text" name="project_end" id="project_end" class="datepicker"
								   placeholder="<?php echo date( 'd-m-Y' ); ?>"/>
						</p>
					</div>
				</div>

				<?php
				// SEARCH FOR PROJECT CATEGORIES
				$terms = get_terms( 'project-category', array( 'hide_empty' => false ) );
				if ( $terms ) : ?>
					<p>
						<label for="project_category"><?php _e( 'Project\'s Category:', 'woffice' ); ?></label>
						<?php // DROPDOWN LIST
						echo '<select multiple="multiple" name="project_category[]" class="postform form-control">';
						echo '<option value="no-category">' . __( "No category", "woffice" ) . '</option>';
						foreach ( $terms as $term ) {
							printf( '<option value="%s">%s</option>', esc_attr( $term->slug ), esc_html( $term->name ) );
						}
						echo '</select>'; ?>
					</p>
				<?php endif; ?>

				<?php
				// MEMBERS SELECT
				$tt_users     = array();
				$tt_users_obj = get_users( array( 'fields' => array( 'ID', 'user_nicename', 'display_name' ) ) );
				foreach ( $tt_users_obj as $tt_user ) {
					$tt_users[ $tt_user->ID ] = woffice_get_name_to_display( $tt_user->ID );
				} ?>
				<p>
					<label for="project_members"><?php _e( 'Project\'s members:', 'woffice' ); ?></label>
					<small><?php _e( 'If it\'s empty, all members\'ll be allowed to see it (leave empty for groups projects)', 'woffice' ); ?></small>
					<select multiple="multiple" name="project_members[]" class="form-control">
						<?php
						foreach ( $tt_users as $key => $user ) {
							echo '<option value="' . $key . '">' . $user . '</option>';
						}
						?>
					</select>
				</p>
				<p>
					<span class="wpcf7-checkbox">
						<span class="wpcf7-list-item">
							<label class="frontend-checkbox">
								<input type="checkbox" name="only_author_can_edit" id="only_author_can_edit"
									   value="yes">
								<span
									class="wpcf7-list-item-label"><?php _e( "Only author can edit ?", "woffice" ); ?></span>
							</label>
						</span>
					</span>
				</p>

				<?php if(class_exists('EventON')): ?>
				<p>
					<span class="wpcf7-checkbox">
						<span class="wpcf7-list-item">
							<label class="frontend-checkbox">
								<input type="checkbox" name="calendar_sync" id="calendar_sync" value="yes">
								<span class="wpcf7-list-item-label"><?php _e( "Calendar sync ?", "woffice" ); ?></span>
							</label>
						</span>
					</span>
				</p>
				<?php endif; ?>
				<p>
					<span class="wpcf7-checkbox">
						<span class="wpcf7-list-item">
							<label class="frontend-checkbox">
								<input type="checkbox" name="enable_todo" id="enable_todo" value="yes">
								<span
									class="wpcf7-list-item-label"><?php _e( "Enable project Todo ?", "woffice" ); ?></span>
							</label>
						</span>
					</span>
				</p>

				<?php if(defined('fileaway')): ?>
				<p>
					<span class="wpcf7-checkbox">
						<span class="wpcf7-list-item">
							<label class="frontend-checkbox">
								<input type="checkbox" name="enable_files" id="enable_files" value="yes">
								<span
									class="wpcf7-list-item-label"><?php _e( "Enable project Files Manager ?", "woffice" ); ?></span>
							</label>
						</span>
					</span>
				</p>
				<?php endif; ?>

			<?php } elseif ( $type == 'directory' ) {
				/* if it's for a Directory POST */
				?>

				<?php

				/* Function that output a field creator like the projects taks
					'box-options' => array(
				   'title' => array( 'type' => 'text', 'label' => __('Content', 'woffice')),
				   'icon' => array( 'type' => 'icon', 'label' => __('Icon', 'woffice'),'value' => 'fa-star'),
			   ),
				*/

				?>

				<div class="row">
					<div class="col-md-6">
						<p>
							<label for="item_location_lng"><?php _e( 'Location\'s Longitude :', 'woffice' ); ?></label>
							<small><?php _e( 'You can use : ', 'woffice' ); ?><a href="http://www.latlong.net/"
																				 target="_blank">LatLong.net</a></small>
							<input type="text" name="item_location_lng" id="item_location_lng"
								   placeholder="-88.242188"/>
						</p>
					</div>
					<div class="col-md-6">
						<p>
							<label for="item_location_lat"><?php _e( 'Location\'s Latitude :', 'woffice' ); ?></label>
							<small><?php _e( 'You can use : ', 'woffice' ); ?><a href="http://www.latlong.net/"
																				 target="_blank">LatLong.net</a></small>
							<input type="text" name="item_location_lat" id="item_location_lat" placeholder="37.544577"/>
						</p>
					</div>
				</div>

				<div class="row">
					<div class="col-md-6">
						<p>
							<label for="item_button_text"><?php _e( 'Button\'s text:', 'woffice' ); ?></label>
							<small><?php _e( 'Button will be displayed on the single page.', 'woffice' ); ?></small>
							<input type="text" name="item_button_text" id="item_button_text"/>
						</p>
					</div>
					<div class="col-md-6">
						<p>
							<label
								for="item_button_icon"><?php _e( 'Button\'s Icon (Font Awesome) :', 'woffice' ); ?></label>
							<small><?php _e( 'Please see : ', 'woffice' ); ?><a
									href="http://fortawesome.github.io/Font-Awesome/icons/" target="_blank">FontAwesome
									Icons</a></small>
							<input type="text" name="item_button_icon" id="item_button_icon" placeholder="fa-star"/>
						</p>
					</div>
					<div class="col-md-12">
						<p>
							<label for="item_button_link"><?php _e( 'Button\'s Link :', 'woffice' ); ?></label>
							<input type="text" name="item_button_link" id="item_button_link"/>
						</p>
					</div>
				</div>

				<?php
				// SEARCH FOR DIRECTORY CATEGORIES
				$terms = get_terms( 'directory-category', array( 'hide_empty' => false ) );
				if ( $terms ) : ?>
					<p>
						<label for="directory_category"><?php _e( 'Directory\'s Category:', 'woffice' ); ?></label>
						<?php // DROPDOWN LIST
						echo '<select multiple="multiple" name="directory_category[]" class="postform form-control">';
						echo '<option value="no-category">' . __( "No category", "woffice" ) . '</option>';
						foreach ( $terms as $term ) {
							printf( '<option value="%s">%s</option>', esc_attr( $term->slug ), esc_html( $term->name ) );
						}
						echo '</select>'; ?>
					</p>
				<?php endif; ?>

			<?php } else {
				/* if it's for a POST POST */
				?>

				<?php
				// SEARCH FOR BLOG CATEGORIES
				$blog_categories_args = array(
					'type'       => 'post',
					'orderby'    => 'name',
					'order'      => 'ASC',
					'number'     => '0',
					'taxonomy'   => 'category',
					'hide_empty' => false
				);
				$terms                = get_categories( $blog_categories_args );
				if ( $terms ) : ?>
					<p>
						<label for="blog_category"><?php _e( 'Article\'s Category :', 'woffice' ); ?></label>
						<?php // DROPDOWN LIST
						echo '<select multiple="multiple" name="blog_category[]" class="postform form-control">';
						echo '<option value="no-category">' . __( "No category", "woffice" ) . '</option>';
						foreach ( $terms as $term ) {
							printf( '<option value="%s">%s</option>', esc_attr( $term->slug ), esc_html( $term->name ) );
						}
						echo '</select>'; ?>
					</p>
				<?php endif; ?>

			<?php }

			if ( $type != 'wiki' && $type != 'project' ) { ?>

				<p>
					<label for="post_thumbnail"><?php _e( 'Article\'s Thumbnail :', 'woffice' ); ?></label>
					<input type="file" name="post_thumbnail" id="post_thumbnail">
				</p>

			<?php } ?>

			<p>
				<?php /* Content Label */
				$content_label = ( $type == "project" ) ? __( 'Project\'s Description:', 'woffice' ) : __( 'Article\'s Content:', 'woffice' ); ?>
				<label for="post_content"><?php echo $content_label; ?></label>
				<?php
				$settings = array(
					'textarea_name' => 'post_content',
					'textarea_rows' => '20',
					'dfw'           => true
				);
				wp_editor( '', 'post_content', $settings );
				?>
			</p>

			<?php if ( $type == 'blog' ):
				if ( woffice_current_is_admin() ):
					?>
					<p>
						<label for="everyone_edit"><?php esc_html_e('Everyone can edit?', 'woffice') ?></label>
						<input type="checkbox" name="everyone_edit" id="everyone_edit" value="yes"/>
					</p>
				<?php endif; ?>
			<?php endif; ?>

			<p class="text-right">
				<?php wp_nonce_field( 'post_nonce', 'post_nonce_field' ); ?>
				<input type="hidden" name="submitted" id="submitted" value="true"/>
				<?php /* Button Label */
				$button_label = ( $type == "project" ) ? __( 'Create Project', 'woffice' ) : __( 'Create Article', 'woffice' ); ?>
				<button type="submit" class="btn btn-default"><i class="fa fa-pencil"></i> <?php echo $button_label; ?>
				</button>
			</p>
		</form>
		<?php

		/* This is the "Go Back" button */
		echo '<div class="center">
			<a href="javascript:void(0)" class="btn btn-default" id="hide-' . $type . '-create">
				<i class="fa fa-arrow-left"></i> ' . __( "Go Back", "woffice" ) . '
			</a>
		</div>';
		echo '</div>';


	}
}

if(!function_exists('woffice_addable_option_form')) {
	/**
	 * We re-recreate an addable option
	 * http://manual.unyson.io/en/latest/options/built-in-option-types.html#addable-option
	 * On the FRONTEND, this is relative to a post
	 * $post_id INTEGER, it's the post's ID
	 * $field_name STRING, it's the field's name
	 * $field_options ARRAY, an array of Unyson options
	 * $field_label STRING, it's the field's label
	 * -
	 * Returns HTTML
	 *
	 * Not Ready for now ....
	 */
	function woffice_addable_option_form( $post_id, $field_name, $field_options, $field_label ) {

		if ( empty( $post_id ) || empty( $field_name ) || empty( $field_options ) || empty( $field_label ) ) {
			return;
		}

		//
		// We display the current values
		//
		/* Get all the existing todos : */
		$box_content = ( function_exists( 'fw_get_db_post_option' ) ) ? fw_get_db_post_option( $post_id, $field_name ) : '';
		/*Values */
		echo '<form id="woffice-addable-box-list" class="woffice-project-todo-group" action="' . $_SERVER['REQUEST_URI'] . '" method="POST">';
		/* First we display all the values */
		if ( ! empty( $box_content ) ) {
			echo '<input type="hidden" name="post_ID" value="' . $post_id . '" />';
			$counter = 0;
			foreach ( $box_content as $fields ) {
				$note_class = "";
				echo '<div class="woffice-box ' . $note_class . '">';
				echo '<ul>';
				/* We display each field within the box */
				foreach ( $fields as $field_name => $field_value ) {
					echo '<li><i class="fa fa-arrow-right"></i> ' . $field_name . '</li>';
				}
				echo '</ul>';

				/* Delete Icon */
				echo '<a href="#" onclick="return false" class="woffice-box-delete"><i class="fa fa-trash-o"></i></a>';

				/* We create some input fields to pass the data through ajax form */
				foreach ( $fields as $field_name => $field_value ) {
					echo '<li><i class="fa fa-arrow-right"></i> ' . $field_name . '</li>';
					echo '<input type="hidden" name="addable_list[' . $counter . '][' . $field_name . ']" value="' . $field_value . '" />';
				}
				/* Other Data */
				echo '<input type="hidden" name="post_ID" value="' . $post_id . '" />';
				echo '<input type="hidden" name="action" value="wofficeAddableDelete" />';
				echo '</div>';
				$counter ++;
			}
		}
		echo '</form>';

		//
		// THE FORM TO ADD A NEW BOX
		//
		echo '<div id="woffice-addable-box-alert"></div>';
		echo '<form id="woffice-addable-box" action="' . $_SERVER['REQUEST_URI'] . '" method="POST">';
		/* The heading */
		echo '<div class="heading"><h3>' . $field_label . '</h3></div>';

		/* The Fields */
		foreach ( $field_options as $option_name => $option ) {
			echo '<div class="row">';
			echo '<div class="col-md-6">';
			echo '<label for="' . $option_name . '">' . $option->label . '</label>';
			if ( $option->type == "text" ) {
				echo '<input type="text" name="' . $option_name . '" required="required">';
			} elseif ( $option->type == "textarea" ) {
				echo '<textarea rows="2" name="' . $option_name . '"></textarea>';
			} elseif ( $option->type == "icon" ) {
				echo '<select name="' . $option_name . '" class="form-control">';
				// We grab all the icons :
				$response_icon = wp_remote_get( 'https://raw.githubusercontent.com/Smartik89/SMK-Font-Awesome-PHP-JSON/master/font-awesome/json/font-awesome-data-readable.json' );
				if ( is_array( $response_icon ) ) {
					$body  = $response_icon['body']; // use the content
					$icons = json_decode( $body );
					foreach ( $icons as $class => $name ) {
						echo '<option value="' . $class . '"><i class="fa ' . $class . '></i> "' . $name . '</option>';
					}
				} else {
					echo '<option value="no-icon">' . __( 'No icon available.', 'woffice' ) . '</option>';
				}
				echo '</select>';
			}
			echo '</div>';
			echo '</div>';
		}

		/* Submit button */
		echo '<div class="text-right">';
		echo '<button type="submit" class="btn btn-default"><i class="fa fa-plus-square-o"></i> ' . __( 'Add a box', 'woffice' ) . '</button>';
		echo '</div>';

		/* Passing extra args */
		echo '<input type="hidden" name="post_ID" value="' . $field_name . '" />';
		echo '<input type="hidden" name="option_name" value="' . $post_id . '" />';
		echo '<input type="hidden" name="action" value="wofficeAddableFrontend" />';
		echo '</form>';

		/* SCRIPT called */
		echo '<script type="text/javascript">
	jQuery(document).ready( function() {
		// Delete Box
		jQuery(".woffice-box").on("click", ".woffice-box-delete", function(){
			var Item = jQuery(this).closest(".woffice-box");
			Item.remove();
			var woffice_BoxDelete_data = jQuery("#woffice-addable-box-list").serialize();
			jQuery.ajax({
				type:"POST",
				url: "' . get_site_url() . '/wp-admin/admin-ajax.php",
				data: woffice_BoxDelete_data,
				success:function(returnval){
					console.log("task removed");
					jQuery("#woffice-addable-box-alert").html(returnval);
					jQuery("#woffice-addable-box-alert div.infobox").hide(4000, function(){ jQuery("#woffice-addable-box-alert div.infobox").remove(); });
				},
			}); return false;
		});

	});
	</script>';

	}
}

//
// AJAX HANDLERS
// 
/*function wofficeAddableFrontend(){
	
	// We get the ID from the current post
	$the_ID = $_POST['post_ID'];
	// We get the current option name 
	$the_option = $_POST['option_name'];
	
	if (!empty($the_ID)) {
		// We get the value which is an array : 
		$the_option_array = ( function_exists( 'fw_get_db_post_option' ) ) ? fw_get_db_post_option($the_ID, $the_option) : '';
		if (!empty($the_option_array)){
			print_r($_POST);	
		}
		//fw_set_db_post_option($post_id, $option_id, $value)
	}
	
	//if($updated) {
	//	echo '<div class="infobox fa fa-trash-o" style="background-color: #CC0000;"><p>';
	//		_e('The option has been deleted !','woffice'); 
	//	echo'</p></div>';
	//}
	
	die();
}
add_action('wp_ajax_nopriv_wofficeAddableFrontend', 'wofficeAddableFrontend');
add_action('wp_ajax_wofficeAddableFrontend', 'wofficeAddableFrontend');*/

if(!function_exists('woffice_edit_allowed')) {
	function woffice_edit_allowed( $post_type = null, $editing_type = 'edit' ) {

		/* If the users is not logged we reeturn false */
		if ( ! is_user_logged_in() || is_null( $post_type ) ) {
			return false;
		}

		/* We get the current user data */
		$user = wp_get_current_user();

		//Check if woffice permissions settings are overrited by meta caps
		$use_meta_caps = woffice_check_meta_caps( $post_type );
		global $post;

		if ( $use_meta_caps ) {

			$slug   = woffice_get_slug_for_meta_caps( $post_type );
			$prefix = ( $post_type != 'post' ) ? 'woffice_' : '';

			//If the post is aleady published then user needs an additional capability
			$published_cap_bool = ( ( $post->post_status == 'publish' && current_user_can( $prefix . $editing_type . '_published_' . $slug ) ) || $post->post_status == 'draft' );

			if ( $post->post_author == $user->ID && current_user_can( $prefix . $editing_type . '_' . $slug ) && $published_cap_bool ) {
				return true;
			}

			if ( $post->post_author != $user->ID && current_user_can( $prefix . $editing_type . '_others_' . $slug ) && $published_cap_bool ) {
				return true;
			}

		} else {
			/*We get TRUE or FALSE from the settings */
			$everyone_edit = ( function_exists( 'fw_get_db_post_option' ) ) ? fw_get_db_post_option( get_the_ID(), 'everyone_edit' ) : '';

			//Check if the current user is the author of the post or is an admin
			//Both are always allowed to edit by frontend
			if ( $post->post_author == $user->ID || woffice_current_is_admin() ) {
				return true;
			} else //we check if it's allowed to others
				if ( $everyone_edit == true ) {

					//Get te roles allowed to edit the current post type
					$roles_selected = array();
					if ( $post_type == 'wiki' || $post_type == 'post' ) {
						$roles_selected = woffice_get_settings_option( $post_type . '_edit' );
					}

					//Check if the current user has one of that roles assigned
					$the_user_role = (array) $user->roles;

					$role_intersect = array_intersect( $the_user_role, $roles_selected );

					return ( ! empty( $role_intersect ) );

				} else {
					return false;
				}
		}

	}
}


if(!function_exists('woffice_render_featured_image_single_post')) {
	function woffice_render_featured_image_single_post( $id, $featured_height = "", $masonry = false ) {
		/*GETTING THE POST THUMBNAIL URL*/
		$auto_height = woffice_get_settings_option( 'auto_height_featured_image', 'nope');

		// Full
		$image_full_url = wp_get_attachment_url( get_post_thumbnail_id( $id ) );
		// 800x600?
		$image_large_url = wp_get_attachment_image_src( get_post_thumbnail_id( $id ), array(800,600) );
		// 600 x 600?
		//$image_medium_url = wp_get_attachment_image_src( get_post_thumbnail_id( $id ), array(600,600) );

		if ( $auto_height == 'auto' ){
			$featured_height = '';
			$auto_height_class = ' auto-height';
		} else {
			$auto_height_class = '';
			$featured_height = ( empty( $featured_height ) ) ? $featured_height : 'height: ' . esc_attr( $featured_height ) . 'px;';
		}

			?>

			<div class="intern-thumbnail <?php echo $auto_height_class ?>" style="<?php echo $featured_height ?>">
				<?php if ( ! is_single() ): ?>
					<a href="<?php the_permalink(); ?>">
				<?php endif; ?>

				<?php

				if($masonry) {
					echo '<picture>';
					echo '<source srcset="'.esc_url($image_full_url).'" media="(min-width: 1920px)" />';
					//echo '<source srcset="'.$image_large_url[0].'"  media="(min-width: 601px)" />';
					echo '<img src="'.$image_large_url[0].'" />';
					echo '</picture>';
				} else {
					echo '<picture>';
					echo '<source srcset="'.esc_url($image_full_url).'" media="(min-width: 801px)" />';
					echo '<img src="'.$image_large_url[0].'" />';
					echo '</picture>';
				}

				?>

				<?php if ( ! is_single() ): ?>
					</a>
				<?php endif; ?>
			</div>
			<?php

	}
}

/*---------------------------------------------------------
**
** TAXONOMY CREATOR FROM FRONTEND TEMPLATE AJAX
**
----------------------------------------------------------*/
function wofficeTaxonomyFetching(){

	// We get the Post Name selected
	$post_name = $_POST['ajax_post_name'];
	if (isset($post_name)) {

		$taxonomy_objects = get_object_taxonomies( $post_name, 'names' );
		echo'<label for="taxonomy"><i class="fa fa-tag"></i> '. __('Choose a taxonomy','woffice') .'</label>';
		echo'<select class="form-control" name="taxonomy">';

		if (!empty($taxonomy_objects)) {
			foreach ($taxonomy_objects as $key=>$taxonomy) {
				echo '<option value="'.$taxonomy.'">'.$taxonomy.'</option>';
			}
		}
		else {
			echo '<option value="no_tax">'. __('No Taxonomy..', 'woffice') .'</option>';
		}

		echo '</select>';

	}
	wp_die();
}
add_action('wp_ajax_nopriv_wofficeTaxonomyFetching', 'wofficeTaxonomyFetching');
add_action('wp_ajax_wofficeTaxonomyFetching', 'wofficeTaxonomyFetching');

function wofficeTaxonomyAdd(){

	// The check the values
	if (empty($_POST['ajax_taxonomy'])) {
		$message = __('You need to choose a taxonomy to add your new category.','woffice');
	}
	elseif (empty($_POST['ajax_new_tax'])) {
		$message = __('You need to enter a new category.','woffice');
	}
	else {
		// We set the new term :
		$tax_ready = sanitize_text_field($_POST['ajax_new_tax']);
		$taxonomy = sanitize_text_field($_POST['ajax_taxonomy']);

		if ($taxonomy != 'no_tax') {

			// We insert the tax
			$insert_term = wp_insert_term( $tax_ready, $taxonomy);

			$message = __('Successfully Added.','woffice');

		}
	}

	echo '<div class="infobox notification-color">'.$message.'</div>';

	wp_die();
}
add_action('wp_ajax_nopriv_wofficeTaxonomyAdd', 'wofficeTaxonomyAdd');
add_action('wp_ajax_wofficeTaxonomyAdd', 'wofficeTaxonomyAdd');
