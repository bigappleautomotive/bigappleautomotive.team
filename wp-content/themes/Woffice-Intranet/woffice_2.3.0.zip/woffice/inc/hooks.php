<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }
/**
 * This files contains custom hooks/actions/filters used by Woffice
 * You can find many of them organized within woffice/inc/classes/
 */

/**
 * Temporary patch regarding
 * Wordpress Pro Event Calendar and Unyson Map conflict
 * We can't stop the plugin to load the API and the MAPS API loaded
 * doesn't have all the parameters requested by the Unyson map option type
 * "Cannot read property 'Autocomplete' of undefined"
 * @since 2.1.5
 */
function remove_dpProEvent_Google_Map() {
	wp_deregister_script('gmaps');
}
add_action('admin_enqueue_scripts', 'remove_dpProEvent_Google_Map', 99);

/*---------------------------------------------------------
** 
** WOFFICE WOOCOMMERCE
**
----------------------------------------------------------*/
if (function_exists('is_woocommerce')) {
	/* Single product change */
	remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
	/* Change number of related products on product page & other */
	add_filter( 'woocommerce_output_related_products_args', 'woffice_related_products_args' );
	function woffice_related_products_args( $args ) {
	
		$args['posts_per_page'] = 4; // 4 related products
		$args['columns'] = 4; // arranged in 2 columns
		return $args;
	}
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
	add_action( 'woocommerce_after_single_product_summary', 'woffice_woocommerce_output_upsells', 15 );
	if ( ! function_exists( 'woocommerce_output_upsells' ) ) {
		function woffice_woocommerce_output_upsells() {
		    woocommerce_upsell_display( 4,4 ); // Display 3 products in rows of 3
		}
	}
	/*add_filter( 'woocommerce_cross_sells_columns', 'woffice_cross_sells_columns' );
	function woffice_cross_sells_columns( $columns ) {
		return 1;
	}*/
	/* Ensure cart contents update when products are added to the cart via AJAX */
	add_filter( 'woocommerce_add_to_cart_fragments', 'woffice_woocommerce_header_add_to_cart_fragment' );
	
	function woffice_woocommerce_header_add_to_cart_fragment( $fragments ) {
		ob_start();
		?>
		<a href="javascript:void(0)" id="nav-cart-trigger" title="<?php _e( 'View your shopping cart', 'woffice' ); ?>" class="<?php echo sizeof(WC()->cart->get_cart()) > 0 ? 'active' : ''; ?> cart-contents">
			<i class="fa fa-shopping-cart"></i>
			<?php echo (sizeof( WC()->cart->get_cart()) > 0) ? WC()->cart->get_cart_subtotal() : ''; ?>
		</a>
		<?php
		
		$fragments['a.cart-contents'] = ob_get_clean();
		
		return $fragments;
	}
	/* Custom Shoping Cart in the top */
	function woffice_wc_print_mini_cart() {
		?>
		<div id="woffice-minicart-top">
			<?php if ( sizeof( WC()->cart->get_cart() ) > 0 ) : ?>
				<ul class="woffice-minicart-top-products">
					<?php foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) :
					$_product = $cart_item['data'];
					// Only display if allowed
					if ( ! apply_filters('woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key ) || ! $_product->exists() || $cart_item['quantity'] == 0 ) continue;
					// Get price
					$product_price = get_option( 'woocommerce_tax_display_cart' ) == 'excl' ? $_product->get_price_excluding_tax() : $_product->get_price_including_tax();
					$product_price = apply_filters( 'woocommerce_cart_item_price_html', woocommerce_price( $product_price ), $cart_item, $cart_item_key );
					?>
					<li class="woffice-mini-cart-product clearfix">
						<span class="woffice-mini-cart-thumbnail">
							<?php echo $_product->get_image(); ?>
						</span>
						<span class="woffice-mini-cart-info">
							<a class="woffice-mini-cart-title" href="<?php echo get_permalink( $cart_item['product_id'] ); ?>">
								<h4><?php echo apply_filters('woocommerce_widget_cart_product_title', $_product->get_title(), $_product ); ?></h4>
							</a>
							<?php echo apply_filters( 'woocommerce_widget_cart_item_price', '<span class="woffice-mini-cart-price">' . __('Unit Price', 'woffice') . ':' . $product_price . '</span>', $cart_item, $cart_item_key ); ?>
							<?php echo apply_filters( 'woocommerce_widget_cart_item_quantity', '<span class="woffice-mini-cart-quantity">' . __('Quantity', 'woffice') . ':' . $cart_item['quantity'] . '</span>', $cart_item, $cart_item_key ); ?>
						</span>
					</li>
					<?php endforeach; ?>
				</ul><!-- end .tee-mini-cart-products -->
			<?php else : ?>
				<p class="woffice-mini-cart-product-empty"><?php _e( 'No products in the cart.', 'woffice' ); ?></p>
			<?php endif; ?>
			<?php if (sizeof( WC()->cart->get_cart()) > 0) : ?>
				<h4 class="text-center woffice-mini-cart-subtotal"><?php _e( 'Cart Subtotal', 'woffice' ); ?>: <?php echo WC()->cart->get_cart_subtotal(); ?></h4>
				<div class="text-center">
					<a href="<?php echo WC()->cart->get_cart_url(); ?>" class="cart btn btn-default">
						<i class="fa fa-shopping-cart"></i> <?php _e( 'Cart', 'woffice' ); ?>
					</a>
					<a href="<?php echo WC()->cart->get_checkout_url(); ?>" class="alt checkout btn btn-default">
						<i class="fa fa-credit-card"></i> <?php _e( 'Checkout', 'woffice' ); ?>
					</a>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

    function woffice_preserve_lostpassword_link() {
        return get_option('siteurl') .'/wp-login.php?action=lostpassword';
    }
    add_filter( 'lostpassword_url',  'woffice_preserve_lostpassword_link', 11, 0 );
}
/*---------------------------------------------------------
** 
** Buddypress patch
**
----------------------------------------------------------*/

function woffice_fix_buddypress_style() {
	echo '<style>
      .bp-profile-field .datebox > label:first-child {width: 200px;}
      .bp-profile-field .datebox > label{width: auto;}
      .bp-profile-field select{margin-right:20px}
     </style>';
}
add_action('admin_print_scripts', 'woffice_fix_buddypress_style');

/*---------------------------------------------------------
** 
** REMOVE EVENTON WIDGETS
**
----------------------------------------------------------*/
if (class_exists( 'EventON' )):
	if(!function_exists('wofffice_remove_eventON_widget')) {
		function wofffice_remove_eventON_widget() {
			unregister_widget( 'EvcalWidget' );
			unregister_widget( 'EvcalWidget_SC' );
			unregister_widget( 'EvcalWidget_three' );
			unregister_widget( 'EvcalWidget_four' );
		}
	}
	add_action( 'widgets_init', 'wofffice_remove_eventON_widget' );
endif;
if (class_exists( 'EventON_full_cal' )):
	if(!function_exists('woffice_remove_eventON_FC_widget')) {
		function woffice_remove_eventON_FC_widget() {
			unregister_widget( 'evoFC_Widget' );
		}
	}
	//add_action( 'widgets_init', 'woffice_remove_eventON_FC_widget',11 );
endif;

/*---------------------------------------------------------
** 
** REMOVE WISE CHAT WIDGET
**
----------------------------------------------------------*/
if (class_exists( 'WiseChat' )):
	function woffice_remove_wise_widget() {
		unregister_widget('WiseChatWidget');
	}
	//add_action( 'widgets_init', 'woffice_remove_wise_widget',11 );
endif;

/*---------------------------------------------------------
** 
** MV FIle Sharing Customization
**
----------------------------------------------------------*/
if (class_exists( 'multiverso_mv_category_files' )):
	function woffice_remove_mv_widget() {
		unregister_widget('multiverso_mv_category_files');
		unregister_widget('multiverso_login_register');
		unregister_widget('multiverso_mv_personal_recent_files');
		unregister_widget('multiverso_mv_recent_files');
		unregister_widget('multiverso_search');
		unregister_widget('multiverso_mv_registered_recent_files');
	}
	add_action( 'widgets_init', 'woffice_remove_mv_widget' );

	// NEW ALL FILES SHORTCODE TO EXCLUDE PORTFOLIO NEW CATEGORY
	function woffice_allfiles() {
		// Include allfiles.php template
		return include(get_template_directory() . '/inc/allfiles.php');
	}
	add_shortcode( 'woffice_allfiles', 'woffice_allfiles' );
	
endif;

/*---------------------------------------------------------
** 
** BBPRESS STUFF
**
----------------------------------------------------------*/
if (class_exists( 'bbPress' )):
	function woffice_remove_bbp_widget() {	
		unregister_widget('BBP_Login_Widget');
	}
	add_action( 'widgets_init', 'woffice_remove_bbp_widget' );
endif;

/*---------------------------------------------------------
**
** FIX 404 ERROR AFTER DELETING POST
**
----------------------------------------------------------*/
add_action( 'parse_request', 'woffice_trashed_post_handler' );
if(!function_exists('woffice_trashed_post_handler')) {
	function woffice_trashed_post_handler() {
		if ( ! is_admin() && ( ( array_key_exists( 'deleted', $_GET ) && $_GET['deleted'] == '1' ) || ( array_key_exists( 'trashed', $_GET ) && $_GET['trashed'] == '1' ) ) ) {
			wp_redirect( home_url() );
			exit;
		}
	}
}

/*---------------------------------------------------------
**
** FEEDS
**
----------------------------------------------------------*/

add_action('do_feed', 'woffice_display_feeds_error', 1);
add_action('do_feed_rdf', 'woffice_display_feeds_error', 1);
add_action('do_feed_rss', 'woffice_display_feeds_error', 1);
add_action('do_feed_rss2', 'woffice_display_feeds_error', 1);
add_action('do_feed_atom', 'woffice_display_feeds_error', 1);
add_action('do_feed_rss2_comments', 'woffice_display_feeds_error', 1);
add_action('do_feed_atom_comments', 'woffice_display_feeds_error', 1);
add_action('bp_activity_sitewide_feed', 'woffice_display_feeds_error_2', 1);
add_action('bp_activity_personal_feed', 'woffice_display_feeds_error_2', 1 );
add_action('bp_activity_friends_feed', 'woffice_display_feeds_error_2', 1 );
add_action('bp_activity_my_groups_feed', 'woffice_display_feeds_error_2', 1 );
add_action('bp_activity_mentions_feed', 'woffice_display_feeds_error_2', 1 );
add_action('bp_activity_favorites_feed', 'woffice_display_feeds_error_2', 1 );
add_action('groups_group_feed', 'woffice_display_feeds_error_2', 1 );


if(!function_exists('woffice_display_feeds_error')) {
	function woffice_display_feeds_error() {
		$feeds_private = woffice_get_settings_option('feeds_private');
		if($feeds_private) {
			wp_die( __( 'No feed available,please visit our <a href="' . site_url() . '">homepage</a>!', 'woffice' ) );
		}
	}
}

if(!function_exists('woffice_display_feeds_error_2')) {
	function woffice_display_feeds_error_2() {
		$feeds_private = woffice_get_settings_option('feeds_private');
		if($feeds_private) {
			echo '>';
			echo '</rss>';
			die();
		}
	}
}


/*---------------------------------------------------------
**
** FIX GOOGLE MAP ALERT ISSUE
**
----------------------------------------------------------*/
if(!function_exists('_action_theme_replace_gmaps_script')) {
	function _action_theme_replace_gmaps_script() {
		$handle = 'google-maps-api-v3';

		if ( ! wp_script_is( $handle ) || ! defined( 'FW' ) ) {
			return;
		}

		// https://github.com/ThemeFuse/Unyson/blob/v2.5.6/framework/includes/option-types/map/class-fw-option-type-map.php#L32-L38
		{
			wp_dequeue_script( $handle );
			wp_deregister_script( $handle );
		}

		/* GET THE API KEY */
		$key_option = woffice_get_settings_option('gmap_api_key');
		if (!empty($key_option)){
			$key = $key_option;
		}
		else {
			$key = "AIzaSyAyXqXI9qYLIWaD9gLErobDccodaCgHiGs";
		}

		wp_enqueue_script(
			$handle,
			'https://maps.googleapis.com/maps/api/js?' . http_build_query( array(
				'v'         => '3.15',
				'libraries' => 'places',
				'language'  => substr( get_locale(), 0, 2 ),
				'key'       => $key,
			) ),
			array(),
			fw()->manifest->get_version(),
			true
		);

	}
}

if(!function_exists('_action_theme_fw_init')) {
	function _action_theme_fw_init() {

		if ( fw()->extensions->get( 'page-builder' ) ) {
			// https://github.com/ThemeFuse/Unyson-PageBuilder-Extension/commit/a780e1789e6ff454e3382ac71dd98c78b7844037
			if ( version_compare( fw_ext( 'page-builder' )->manifest->get_version(), '1.5.6', '>=' ) ) {
				add_action( 'admin_enqueue_scripts', '_action_theme_replace_gmaps_script', 20 );
			} else {
				add_action( 'admin_print_scripts', '_action_theme_replace_gmaps_script', 20 );
			}

		}

	}
}

add_action('fw_init', '_action_theme_fw_init');

if(!function_exists('woffice_avoid_eventon_maps_conflict')) {
	function woffice_avoid_eventon_maps_conflict() {
		if ( wp_script_is( 'google-maps-api-v3' ) ) {
			wp_dequeue_script( 'evcal_gmaps' );
			wp_deregister_script( 'evcal_gmaps' );
		}
	}
}
add_action('wp_enqueue_scripts', 'woffice_avoid_eventon_maps_conflict', 99);
/*---------------------------------------------------------
**
** SEARCH FILTERS
**
----------------------------------------------------------*/
if(!function_exists('woffice_add_bp_mentions_on_comments_area')) {
	/**
	 * Enable buddypress mentions on every comment area
	 *
	 * @param $field
	 *
	 * @return mixed
	 */
	function woffice_add_bp_mentions_on_comments_area( $field ) {
		/*if(strpos($field, 'class="') !== false)
			return str_replace( 'class="', 'class="bp-suggestions ', $field );
		else
			return str_replace( 'id="comment"', 'id="comment" class="bp-suggestions"', $field );
		*/
		return str_replace( 'textarea', 'textarea class="bp-suggestions"', $field );
	}
}
add_filter( 'comment_form_field_comment', 'woffice_add_bp_mentions_on_comments_area' );