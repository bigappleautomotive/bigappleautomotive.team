<?php
/**
 * The Content Sidebar
 */
?>
	<!-- RIGHT SIDE -> SIDEBAR-->
	<aside id="right-sidebar" class="mobile-hidden" role="complementary">

		<?php dynamic_sidebar( apply_filters('woffice_override_content_sidebar', 'content') ); ?>
		
	</aside>