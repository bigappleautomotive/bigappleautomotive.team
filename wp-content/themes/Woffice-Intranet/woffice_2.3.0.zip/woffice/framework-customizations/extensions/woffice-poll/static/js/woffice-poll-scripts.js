(function($){

	/**
	 * LOADING
	 */
	 
	 $("#woffice_poll button.btn").on('click', function(){
	 
    	$('#poll-loader').slideDown();
		$("#woffice_poll").hide();
		
	});

})(jQuery);