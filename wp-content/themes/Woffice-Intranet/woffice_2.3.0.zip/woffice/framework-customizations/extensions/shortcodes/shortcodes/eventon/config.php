<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'EventOn', 'woffice' ),
	'description' => __( 'Add a full month calendar from EventON events or a single event', 'woffice' ),
	'tab'         => __( 'Content Elements', 'woffice' ),
	'icon' 		  => 'fa fa-calendar',
);