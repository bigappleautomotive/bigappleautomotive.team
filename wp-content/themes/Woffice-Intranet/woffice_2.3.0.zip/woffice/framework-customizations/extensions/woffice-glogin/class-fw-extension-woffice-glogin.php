<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
/**
 *  Inspired by http://www.sitepoint.com/adding-a-google-sign-in-to-wordpress/
 */
 
class FW_Extension_Woffice_Glogin extends FW_Extension {
	/**
	 * @internal
	 */
	public function _init() {
	}
	
	/**
	 * 
	 */
	public function woffice_glogin() {
		
	}
}