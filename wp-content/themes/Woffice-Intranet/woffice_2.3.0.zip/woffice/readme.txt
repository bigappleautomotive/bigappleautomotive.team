=== WOFFICE PREMIUM WORDPRESS THEME ===
/*
Theme Name: Woffice 
Theme URI: http://themeforest.net/user/2Fwebd
Author: 2Fwebd
Author URI: http://themeforest.net/user/2Fwebd
Description: Woffice - Intranet multipurpose Wordpress theme
Version: 0.9
Text Domain: woffice
Tags: green, gray, white, dark, light, two-columns, right-sidebar, responsive-layout, accessibility-ready, custom-background, custom-colors, custom-header, custom-menu, editor-style, buddypress, featured-images, sticky-post, threaded-comments, translation-ready
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Domain Path: /languages
*/
